export interface Lesson {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  content: string;
  codeExample: string;
  quiz: QuizQuestion[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
  starterCode: string;
  testCases: TestCase[];
  hints: string[];
  solution: string;
}

export interface TestCase {
  input: string;
  expected: string;
  description: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  topics: string[];
  steps: string[];
  starterCode: string;
  image: string;
}

export const categories = [
  { id: 'basics', name: 'Go Basics', icon: '📦', color: '#10B981' },
  { id: 'functions', name: 'Functions', icon: '⚡', color: '#F59E0B' },
  { id: 'structs', name: 'Structs & Interfaces', icon: '🏗️', color: '#8B5CF6' },
  { id: 'concurrency', name: 'Goroutines & Concurrency', icon: '🚀', color: '#EF4444' },
  { id: 'webdev', name: 'Web Development', icon: '🌐', color: '#3B82F6' },
  { id: 'apis', name: 'APIs & Microservices', icon: '🔌', color: '#EC4899' },
  { id: 'testing', name: 'Testing', icon: '🧪', color: '#14B8A6' },
];

export const lessons: Lesson[] = [
  {
    id: 'hello-world',
    title: 'Hello World in Go',
    description: 'Write your first Go program and understand the basic structure.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '10 min',
    content: `# Hello World in Go

Welcome to your first Go program! Go (often called Golang) is a statically typed, compiled language designed at Google. It's known for its simplicity, efficiency, and excellent support for concurrency.

## Why Go?

- **Simple syntax** – Easy to learn and read
- **Fast compilation** – Compiles to native machine code
- **Built-in concurrency** – Goroutines make concurrent programming easy
- **Strong standard library** – Everything you need out of the box
- **Garbage collected** – Automatic memory management

## Your First Program

Every Go program starts with a \`package\` declaration. The \`main\` package is special – it defines a standalone executable program.

The \`import\` statement brings in packages from the standard library. The \`fmt\` package provides formatted I/O functions.

The \`main()\` function is the entry point of your program. When you run your program, execution starts here.

## Key Concepts

1. **Package declaration** – Every Go file belongs to a package
2. **Import statements** – Bring in external packages
3. **Functions** – Defined with the \`func\` keyword
4. **fmt.Println** – Prints a line to standard output`,
    codeExample: `package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
    fmt.Println("Welcome to Go programming!")
    
    // Variables
    name := "Gopher"
    fmt.Printf("Hello, %s!\\n", name)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What package must the main function be in?',
        options: ['main', 'fmt', 'go', 'app'],
        correctAnswer: 0,
        explanation: 'The main() function must be in the "main" package to create an executable program.',
      },
      {
        id: 'q2',
        question: 'Which package provides the Println function?',
        options: ['io', 'os', 'fmt', 'log'],
        correctAnswer: 2,
        explanation: 'The fmt package provides formatted I/O functions including Println.',
      },
      {
        id: 'q3',
        question: 'What does := do in Go?',
        options: ['Assigns a value', 'Declares and assigns (short variable declaration)', 'Compares values', 'Creates a constant'],
        correctAnswer: 1,
        explanation: 'The := operator is a short variable declaration that both declares and initializes a variable.',
      },
    ],
  },
  {
    id: 'variables-types',
    title: 'Variables & Data Types',
    description: 'Learn about Go\'s type system, variable declarations, and basic data types.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '15 min',
    content: `# Variables & Data Types

Go is a statically typed language, meaning every variable has a specific type determined at compile time.

## Variable Declaration

There are several ways to declare variables in Go:

1. **var keyword** – Full declaration with type
2. **Short declaration (:=)** – Type inferred from value
3. **Multiple variables** – Declare several at once
4. **Constants** – Immutable values with \`const\`

## Basic Types

- **bool** – true or false
- **string** – Text data
- **int, int8, int16, int32, int64** – Signed integers
- **uint, uint8, uint16, uint32, uint64** – Unsigned integers
- **float32, float64** – Floating point numbers
- **complex64, complex128** – Complex numbers
- **byte** – alias for uint8
- **rune** – alias for int32 (Unicode code point)

## Zero Values

Variables declared without initial values get their **zero value**:
- Numeric types: \`0\`
- Boolean: \`false\`
- String: \`""\`
- Pointers: \`nil\``,
    codeExample: `package main

import "fmt"

func main() {
    // var declaration
    var age int = 25
    var name string = "Alice"
    var isStudent bool = true

    // Short declaration
    score := 95.5
    grade := 'A'

    // Multiple variables
    var (
        x int = 10
        y int = 20
    )

    // Constants
    const Pi = 3.14159
    const AppName = "GoMaster"

    fmt.Printf("Name: %s, Age: %d\\n", name, age)
    fmt.Printf("Student: %t, Score: %.1f\\n", isStudent, score)
    fmt.Printf("Grade: %c\\n", grade)
    fmt.Printf("X: %d, Y: %d, Sum: %d\\n", x, y, x+y)
    fmt.Printf("Pi: %.5f, App: %s\\n", Pi, AppName)

    // Zero values
    var zeroInt int
    var zeroStr string
    var zeroBool bool
    fmt.Printf("Zero int: %d, string: '%s', bool: %t\\n", 
        zeroInt, zeroStr, zeroBool)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What is the zero value of a string in Go?',
        options: ['nil', 'null', '""', 'undefined'],
        correctAnswer: 2,
        explanation: 'The zero value of a string is an empty string "".',
      },
      {
        id: 'q2',
        question: 'Which is NOT a valid way to declare a variable in Go?',
        options: ['var x int = 5', 'x := 5', 'let x = 5', 'var x = 5'],
        correctAnswer: 2,
        explanation: 'Go does not use the "let" keyword. Use "var" or ":=" for declarations.',
      },
    ],
  },
  {
    id: 'control-flow',
    title: 'Control Flow',
    description: 'Master if/else, switch statements, and loops in Go.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '20 min',
    content: `# Control Flow in Go

Go provides clean and straightforward control flow constructs.

## If/Else

Go's if statements don't need parentheses around conditions but do require braces. A unique feature: you can include a short statement before the condition.

## Switch

Go's switch is more powerful than many languages – cases don't fall through by default, and you can switch on any type.

## Loops

Go has only one looping construct: the \`for\` loop. But it's versatile enough to handle all loop patterns:

- **Traditional for loop** – \`for i := 0; i < n; i++\`
- **While-style** – \`for condition\`
- **Infinite loop** – \`for\`
- **Range loop** – \`for i, v := range collection\``,
    codeExample: `package main

import "fmt"

func main() {
    // If/Else
    score := 85
    if score >= 90 {
        fmt.Println("Grade: A")
    } else if score >= 80 {
        fmt.Println("Grade: B")
    } else {
        fmt.Println("Grade: C")
    }

    // If with short statement
    if n := score * 2; n > 150 {
        fmt.Println("High score!")
    }

    // Switch
    day := "Monday"
    switch day {
    case "Monday", "Tuesday", "Wednesday", "Thursday", "Friday":
        fmt.Println("Weekday")
    case "Saturday", "Sunday":
        fmt.Println("Weekend!")
    default:
        fmt.Println("Unknown day")
    }

    // For loop
    for i := 0; i < 5; i++ {
        fmt.Printf("Count: %d\\n", i)
    }

    // Range loop
    fruits := []string{"Apple", "Banana", "Cherry"}
    for i, fruit := range fruits {
        fmt.Printf("%d: %s\\n", i, fruit)
    }

    // While-style loop
    n := 1
    for n < 100 {
        n *= 2
    }
    fmt.Printf("Result: %d\\n", n)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'How many loop constructs does Go have?',
        options: ['Three (for, while, do-while)', 'Two (for, while)', 'One (for)', 'Four'],
        correctAnswer: 2,
        explanation: 'Go has only the "for" loop, but it can be used in different styles to cover all looping patterns.',
      },
      {
        id: 'q2',
        question: 'Do switch cases fall through by default in Go?',
        options: ['Yes', 'No', 'Only with break', 'Depends on the type'],
        correctAnswer: 1,
        explanation: 'Unlike C/Java, Go switch cases do NOT fall through by default. Use "fallthrough" keyword if needed.',
      },
    ],
  },
  {
    id: 'user-input',
    title: 'User Input in Go',
    description: 'Read input from the user with fmt.Scan, fmt.Scanln, fmt.Scanf, and bufio.Scanner.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '20 min',
    content: `# User Input in Go

Reading input from the user is fundamental to interactive programs. Go provides several ways to read input, from simple one-liners to full buffered readers.

## fmt.Scan Family

The \`fmt\` package provides three functions for reading input:

- **fmt.Scan(&var)** – Reads space-separated tokens
- **fmt.Scanln(&var)** – Reads until newline
- **fmt.Scanf(format, &var)** – Reads with a format string (like Printf in reverse)

All three take **pointers** to the variables where input should be stored (using the \`&\` operator).

## bufio.Scanner

For reading full lines (including spaces), use \`bufio.Scanner\`:

\`\`\`go
scanner := bufio.NewScanner(os.Stdin)
scanner.Scan()
text := scanner.Text()
\`\`\`

## bufio.NewReader

For more control, \`bufio.NewReader\` lets you read until a specific delimiter:

\`\`\`go
reader := bufio.NewReader(os.Stdin)
text, _ := reader.ReadString('\\n')
\`\`\`

## Converting Input

Input is always read as a string. To convert to other types, use the \`strconv\` package:

- **strconv.Atoi(s)** – String to int
- **strconv.ParseFloat(s, 64)** – String to float64
- **strconv.ParseBool(s)** – String to bool

## Key Points

1. Always use \`&\` (address-of) with Scan functions
2. \`fmt.Scan\` stops at whitespace — use \`bufio\` for full lines
3. Always check for errors when converting types
4. \`strings.TrimSpace()\` removes trailing newlines from bufio input`,
    codeExample: `package main

import "fmt"

func main() {
    // Simple input with fmt.Scan
    var name string
    fmt.Print("What is your name? ")
    fmt.Scan(&name)

    fmt.Printf("Hello, %s!\\n", name)

    // Reading a number
    var age int
    fmt.Print("How old are you? ")
    fmt.Scan(&age)

    fmt.Printf("You are %d years old.\\n", age)

    // Calculate something with the input
    birthYear := 2024 - age
    fmt.Printf("You were born around %d.\\n", birthYear)

    // Reading multiple values
    var width, height float64
    fmt.Print("Enter width and height: ")
    fmt.Scan(&width)
    fmt.Scan(&height)

    area := width * height
    fmt.Printf("Area: %.2f\\n", area)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What operator must you use with fmt.Scan to pass a variable?',
        options: ['*', '&', '->', '.'],
        correctAnswer: 1,
        explanation: 'The & (address-of) operator is required because Scan needs a pointer to the variable to write the input value into it.',
      },
      {
        id: 'q2',
        question: 'Which function reads an entire line including spaces?',
        options: ['fmt.Scan', 'fmt.Scanln', 'bufio.Scanner', 'fmt.Scanf'],
        correctAnswer: 2,
        explanation: 'bufio.Scanner (with scanner.Scan() and scanner.Text()) reads an entire line including spaces. fmt.Scan stops at whitespace.',
      },
      {
        id: 'q3',
        question: 'Which package converts a string to an integer?',
        options: ['fmt', 'strconv', 'strings', 'math'],
        correctAnswer: 1,
        explanation: 'The strconv package provides Atoi() (string to int) and other conversion functions.',
      },
    ],
  },
  {
    id: 'functions-basics',
    title: 'Functions in Go',
    description: 'Learn about function declarations, parameters, return values, and closures.',
    category: 'functions',
    difficulty: 'beginner',
    duration: '20 min',
    content: `# Functions in Go

Functions are central to Go programming. They support multiple return values, named returns, variadic parameters, and first-class functions.

## Key Features

- **Multiple return values** – Return more than one value
- **Named returns** – Name your return values for clarity
- **Variadic functions** – Accept variable number of arguments
- **First-class functions** – Pass functions as arguments
- **Closures** – Functions that capture surrounding state
- **Defer** – Schedule cleanup actions

## Error Handling Pattern

Go doesn't have exceptions. Instead, functions return error values as a second return value. This is idiomatic Go.`,
    codeExample: `package main

import (
    "fmt"
    "errors"
    "strings"
)

// Basic function
func add(a, b int) int {
    return a + b
}

// Multiple return values
func divide(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("division by zero")
    }
    return a / b, nil
}

// Named return values
func rectangleInfo(w, h float64) (area, perimeter float64) {
    area = w * h
    perimeter = 2 * (w + h)
    return // naked return
}

// Variadic function
func sum(nums ...int) int {
    total := 0
    for _, n := range nums {
        total += n
    }
    return total
}

// Higher-order function
func apply(f func(string) string, s string) string {
    return f(s)
}

func main() {
    fmt.Println("3 + 5 =", add(3, 5))

    result, err := divide(10, 3)
    if err != nil {
        fmt.Println("Error:", err)
    } else {
        fmt.Printf("10 / 3 = %.2f\\n", result)
    }

    area, perim := rectangleInfo(5, 3)
    fmt.Printf("Area: %.0f, Perimeter: %.0f\\n", area, perim)

    fmt.Println("Sum:", sum(1, 2, 3, 4, 5))

    upper := apply(strings.ToUpper, "hello go")
    fmt.Println(upper)

    // Closure
    counter := func() func() int {
        count := 0
        return func() int {
            count++
            return count
        }
    }()
    
    fmt.Println(counter(), counter(), counter())
}`,
    quiz: [
      {
        id: 'q1',
        question: 'How does Go handle errors?',
        options: ['Try/Catch blocks', 'Exceptions', 'Returning error values', 'Panic/Recover only'],
        correctAnswer: 2,
        explanation: 'Go uses explicit error return values as the idiomatic way to handle errors.',
      },
      {
        id: 'q2',
        question: 'What does the ... syntax mean in a function parameter?',
        options: ['Spread operator', 'Variadic parameter', 'Array declaration', 'Pointer'],
        correctAnswer: 1,
        explanation: 'The ... syntax creates a variadic parameter that accepts zero or more arguments.',
      },
    ],
  },
  {
    id: 'structs-interfaces',
    title: 'Structs & Interfaces',
    description: 'Build custom types with structs and define behavior with interfaces.',
    category: 'structs',
    difficulty: 'intermediate',
    duration: '25 min',
    content: `# Structs & Interfaces

Go doesn't have classes, but structs and interfaces provide powerful composition-based design.

## Structs

Structs are collections of fields. They're Go's way of creating custom types.

## Methods

You can define methods on struct types using receiver functions.

## Interfaces

Interfaces define behavior – a set of method signatures. Types implement interfaces implicitly (no "implements" keyword).

## Composition

Go favors composition over inheritance. You embed structs within other structs to build complex types.

## Key Principles

- No inheritance – use composition
- Implicit interface implementation
- Small interfaces (often 1-2 methods)
- Accept interfaces, return structs`,
    codeExample: `package main

import (
    "fmt"
    "math"
)

// Struct definition
type Circle struct {
    X, Y   float64
    Radius float64
}

type Rectangle struct {
    Width, Height float64
}

// Interface
type Shape interface {
    Area() float64
    Perimeter() float64
}

// Methods on Circle
func (c Circle) Area() float64 {
    return math.Pi * c.Radius * c.Radius
}

func (c Circle) Perimeter() float64 {
    return 2 * math.Pi * c.Radius
}

// Methods on Rectangle
func (r Rectangle) Area() float64 {
    return r.Width * r.Height
}

func (r Rectangle) Perimeter() float64 {
    return 2 * (r.Width + r.Height)
}

// Function accepting interface
func printShapeInfo(s Shape) {
    fmt.Printf("Area: %.2f, Perimeter: %.2f\\n", 
        s.Area(), s.Perimeter())
}

// Struct embedding (composition)
type ColoredCircle struct {
    Circle
    Color string
}

func main() {
    c := Circle{X: 0, Y: 0, Radius: 5}
    r := Rectangle{Width: 10, Height: 5}

    fmt.Println("Circle:")
    printShapeInfo(c)

    fmt.Println("Rectangle:")
    printShapeInfo(r)

    // Embedded struct
    cc := ColoredCircle{
        Circle: Circle{Radius: 3},
        Color:  "Red",
    }
    fmt.Printf("Colored circle: %s, Area: %.2f\\n", 
        cc.Color, cc.Area())
}`,
    quiz: [
      {
        id: 'q1',
        question: 'How do types implement interfaces in Go?',
        options: ['Using "implements" keyword', 'Using "extends" keyword', 'Implicitly by having the right methods', 'By registering with the interface'],
        correctAnswer: 2,
        explanation: 'Go uses implicit interface implementation – any type that has the required methods automatically satisfies the interface.',
      },
    ],
  },
  {
    id: 'goroutines',
    title: 'Goroutines & Channels',
    description: 'Master Go\'s powerful concurrency primitives.',
    category: 'concurrency',
    difficulty: 'intermediate',
    duration: '30 min',
    content: `# Goroutines & Channels

Go's concurrency model is one of its most powerful features. Goroutines are lightweight threads managed by the Go runtime, and channels provide safe communication between them.

## Goroutines

A goroutine is launched by prefixing a function call with the \`go\` keyword. They're incredibly lightweight – you can run thousands simultaneously.

## Channels

Channels are typed conduits for sending and receiving values between goroutines. They synchronize execution and enable communication.

## Key Concepts

- **go keyword** – Launches a goroutine
- **Channels** – Communication between goroutines
- **Buffered channels** – Channels with capacity
- **Select** – Wait on multiple channel operations
- **WaitGroups** – Wait for goroutines to finish
- **Mutex** – Protect shared state

## Go Proverb
> "Don't communicate by sharing memory; share memory by communicating."`,
    codeExample: `package main

import (
    "fmt"
    "sync"
    "time"
)

// Basic goroutine
func printNumbers(label string, wg *sync.WaitGroup) {
    defer wg.Done()
    for i := 1; i <= 5; i++ {
        fmt.Printf("%s: %d\\n", label, i)
        time.Sleep(100 * time.Millisecond)
    }
}

// Channel example
func producer(ch chan<- int) {
    for i := 0; i < 5; i++ {
        ch <- i * i
    }
    close(ch)
}

// Worker pool pattern
func worker(id int, jobs <-chan int, results chan<- int) {
    for j := range jobs {
        fmt.Printf("Worker %d processing job %d\\n", id, j)
        time.Sleep(time.Millisecond * 100)
        results <- j * 2
    }
}

func main() {
    // WaitGroup for goroutines
    var wg sync.WaitGroup
    wg.Add(2)
    go printNumbers("A", &wg)
    go printNumbers("B", &wg)
    wg.Wait()

    fmt.Println("\\n--- Channels ---")
    ch := make(chan int)
    go producer(ch)
    for val := range ch {
        fmt.Printf("Received: %d\\n", val)
    }

    fmt.Println("\\n--- Worker Pool ---")
    jobs := make(chan int, 5)
    results := make(chan int, 5)

    for w := 1; w <= 3; w++ {
        go worker(w, jobs, results)
    }

    for j := 1; j <= 5; j++ {
        jobs <- j
    }
    close(jobs)

    for i := 0; i < 5; i++ {
        fmt.Printf("Result: %d\\n", <-results)
    }
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What keyword launches a goroutine?',
        options: ['async', 'thread', 'go', 'spawn'],
        correctAnswer: 2,
        explanation: 'The "go" keyword before a function call launches it as a goroutine.',
      },
      {
        id: 'q2',
        question: 'What happens when you send to an unbuffered channel with no receiver?',
        options: ['It drops the value', 'It blocks', 'It panics', 'It returns an error'],
        correctAnswer: 1,
        explanation: 'Sending to an unbuffered channel blocks until there is a receiver ready.',
      },
    ],
  },
  {
    id: 'http-server',
    title: 'Building HTTP Servers',
    description: 'Create web servers using Go\'s net/http package.',
    category: 'webdev',
    difficulty: 'intermediate',
    duration: '25 min',
    content: `# Building HTTP Servers in Go

Go's standard library includes a powerful HTTP server and client. You can build production-ready web servers without any external frameworks.

## net/http Package

The \`net/http\` package provides:
- HTTP server and client implementations
- Request routing (ServeMux)
- Middleware support via handler chaining
- TLS/HTTPS support

## Handlers

An HTTP handler is anything implementing the \`http.Handler\` interface or a function matching \`http.HandlerFunc\` signature.

## Key Patterns

- **Handler functions** – Simple request handlers
- **ServeMux** – Request router/multiplexer
- **Middleware** – Cross-cutting concerns (logging, auth)
- **Templates** – HTML template rendering
- **Static files** – Serving static content`,
    codeExample: `package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "time"
)

type Response struct {
    Message string    \`json:"message"\`
    Time    time.Time \`json:"time"\`
}

// Handler function
func homeHandler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Welcome to Go Web Server!")
}

// JSON API handler
func apiHandler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    resp := Response{
        Message: "Hello from Go API!",
        Time:    time.Now(),
    }
    json.NewEncoder(w).Encode(resp)
}

// Middleware
func loggingMiddleware(next http.HandlerFunc) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        start := time.Now()
        next(w, r)
        log.Printf("%s %s %v", r.Method, r.URL.Path, 
            time.Since(start))
    }
}

func main() {
    mux := http.NewServeMux()
    
    mux.HandleFunc("/", homeHandler)
    mux.HandleFunc("/api/hello", 
        loggingMiddleware(apiHandler))

    fmt.Println("Server starting on :8080")
    log.Fatal(http.ListenAndServe(":8080", mux))
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What package provides HTTP server functionality in Go?',
        options: ['http', 'net/http', 'server', 'web'],
        correctAnswer: 1,
        explanation: 'The net/http package in Go\'s standard library provides HTTP server and client functionality.',
      },
    ],
  },
  {
    id: 'rest-api',
    title: 'RESTful API Design',
    description: 'Build production-ready REST APIs with Go.',
    category: 'apis',
    difficulty: 'advanced',
    duration: '35 min',
    content: `# RESTful API Design in Go

Build robust, production-ready REST APIs using Go's standard library and best practices.

## API Design Principles

- Use proper HTTP methods (GET, POST, PUT, DELETE)
- Return appropriate status codes
- Use JSON for request/response bodies
- Implement proper error handling
- Add middleware for cross-cutting concerns

## Project Structure

A well-organized API follows a clean architecture:
- **handlers** – HTTP request handlers
- **models** – Data structures
- **middleware** – Request/response processing
- **routes** – URL routing configuration

## Best Practices

1. Use context for request-scoped values
2. Implement graceful shutdown
3. Add request validation
4. Use structured logging
5. Handle CORS properly`,
    codeExample: `package main

import (
    "encoding/json"
    "fmt"
    "net/http"
    "sync"
)

type Book struct {
    ID     string \`json:"id"\`
    Title  string \`json:"title"\`
    Author string \`json:"author"\`
    Year   int    \`json:"year"\`
}

type BookStore struct {
    mu    sync.RWMutex
    books map[string]Book
}

func NewBookStore() *BookStore {
    return &BookStore{
        books: map[string]Book{
            "1": {ID: "1", Title: "The Go Programming Language", 
                  Author: "Donovan & Kernighan", Year: 2015},
            "2": {ID: "2", Title: "Go in Action", 
                  Author: "William Kennedy", Year: 2015},
        },
    }
}

func (bs *BookStore) GetAll(w http.ResponseWriter, r *http.Request) {
    bs.mu.RLock()
    defer bs.mu.RUnlock()
    
    books := make([]Book, 0, len(bs.books))
    for _, b := range bs.books {
        books = append(books, b)
    }
    
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(books)
}

func (bs *BookStore) Create(w http.ResponseWriter, r *http.Request) {
    var book Book
    if err := json.NewDecoder(r.Body).Decode(&book); err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }
    
    bs.mu.Lock()
    bs.books[book.ID] = book
    bs.mu.Unlock()
    
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(book)
}

func main() {
    store := NewBookStore()
    
    http.HandleFunc("/api/books", func(w http.ResponseWriter, r *http.Request) {
        switch r.Method {
        case "GET":
            store.GetAll(w, r)
        case "POST":
            store.Create(w, r)
        default:
            http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
        }
    })
    
    fmt.Println("API server running on :8080")
    http.ListenAndServe(":8080", nil)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What HTTP status code should be returned when creating a new resource?',
        options: ['200 OK', '201 Created', '204 No Content', '202 Accepted'],
        correctAnswer: 1,
        explanation: '201 Created is the proper status code for successful resource creation.',
      },
    ],
  },
  {
    id: 'testing-go',
    title: 'Testing in Go',
    description: 'Write unit tests, benchmarks, and table-driven tests.',
    category: 'testing',
    difficulty: 'intermediate',
    duration: '25 min',
    content: `# Testing in Go

Go has excellent built-in support for testing. The \`testing\` package provides tools for unit tests, benchmarks, and examples.

## Test Files

Test files are named with the \`_test.go\` suffix and live alongside the code they test.

## Test Functions

- **Test functions** start with \`Test\` prefix
- **Benchmark functions** start with \`Benchmark\` prefix
- **Example functions** start with \`Example\` prefix

## Table-Driven Tests

A common Go testing pattern where test cases are defined as a slice of structs.

## Running Tests

\`\`\`bash
go test ./...           # Run all tests
go test -v              # Verbose output
go test -run TestAdd    # Run specific test
go test -bench .        # Run benchmarks
go test -cover          # Show coverage
\`\`\``,
    codeExample: `package main

import (
    "fmt"
    "testing"
)

// Functions to test
func Add(a, b int) int {
    return a + b
}

func Divide(a, b float64) (float64, error) {
    if b == 0 {
        return 0, fmt.Errorf("cannot divide by zero")
    }
    return a / b, nil
}

func IsPalindrome(s string) bool {
    for i, j := 0, len(s)-1; i < j; i, j = i+1, j-1 {
        if s[i] != s[j] {
            return false
        }
    }
    return true
}

// Unit test
func TestAdd(t *testing.T) {
    result := Add(2, 3)
    if result != 5 {
        t.Errorf("Add(2, 3) = %d; want 5", result)
    }
}

// Table-driven test
func TestDivide(t *testing.T) {
    tests := []struct {
        name    string
        a, b    float64
        want    float64
        wantErr bool
    }{
        {"positive", 10, 2, 5, false},
        {"negative", -10, 2, -5, false},
        {"zero divisor", 10, 0, 0, true},
        {"decimal", 7, 2, 3.5, false},
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            got, err := Divide(tt.a, tt.b)
            if (err != nil) != tt.wantErr {
                t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
                return
            }
            if got != tt.want {
                t.Errorf("Divide(%v, %v) = %v, want %v", 
                    tt.a, tt.b, got, tt.want)
            }
        })
    }
}

// Benchmark
func BenchmarkIsPalindrome(b *testing.B) {
    for i := 0; i < b.N; i++ {
        IsPalindrome("racecar")
    }
}

func main() {
    fmt.Println("Add(2, 3) =", Add(2, 3))
    fmt.Println("IsPalindrome('racecar'):", IsPalindrome("racecar"))
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What suffix must Go test files have?',
        options: ['.test.go', '_test.go', '_spec.go', '.spec.go'],
        correctAnswer: 1,
        explanation: 'Go test files must end with _test.go to be recognized by the testing framework.',
      },
    ],
  },
  {
    id: 'slices-maps',
    title: 'Slices & Maps',
    description: 'Work with Go\'s essential collection types.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '20 min',
    content: `# Slices & Maps

Slices and maps are Go's most commonly used collection types. Understanding them is essential for effective Go programming.

## Slices

Slices are dynamic, flexible views into arrays. They're more common than arrays in Go code.

## Maps

Maps are Go's built-in hash table / dictionary type. They map keys to values.

## Key Operations

### Slices
- \`make([]T, len, cap)\` – Create a slice
- \`append(slice, elements...)\` – Add elements
- \`slice[low:high]\` – Sub-slice
- \`len()\` and \`cap()\` – Length and capacity
- \`copy(dst, src)\` – Copy elements

### Maps
- \`make(map[K]V)\` – Create a map
- \`m[key] = value\` – Set a value
- \`value, ok := m[key]\` – Get with existence check
- \`delete(m, key)\` – Remove entry
- \`len(m)\` – Number of entries`,
    codeExample: `package main

import "fmt"

func main() {
    // Slices
    nums := []int{1, 2, 3, 4, 5}
    fmt.Println("Slice:", nums)
    
    // Append
    nums = append(nums, 6, 7)
    fmt.Println("After append:", nums)
    
    // Sub-slice
    sub := nums[2:5]
    fmt.Println("Sub-slice [2:5]:", sub)
    
    // Make with capacity
    scores := make([]int, 0, 10)
    for i := 0; i < 5; i++ {
        scores = append(scores, i*10)
    }
    fmt.Printf("Scores: %v (len=%d, cap=%d)\\n", 
        scores, len(scores), cap(scores))
    
    // Maps
    ages := map[string]int{
        "Alice": 30,
        "Bob":   25,
        "Carol": 35,
    }
    fmt.Println("\\nMap:", ages)
    
    // Add entry
    ages["Dave"] = 28
    
    // Check existence
    if age, ok := ages["Alice"]; ok {
        fmt.Printf("Alice is %d years old\\n", age)
    }
    
    // Delete
    delete(ages, "Bob")
    
    // Iterate
    fmt.Println("\\nAll ages:")
    for name, age := range ages {
        fmt.Printf("  %s: %d\\n", name, age)
    }
    
    // Word counter
    text := "go is great go is fast go is fun"
    wordCount := make(map[string]int)
    for _, word := range []string{"go", "is", "great", "go", 
        "is", "fast", "go", "is", "fun"} {
        wordCount[word]++
    }
    fmt.Println("\\nWord counts:", wordCount)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What does append() return?',
        options: ['Nothing (modifies in place)', 'A new slice', 'An error', 'The length'],
        correctAnswer: 1,
        explanation: 'append() returns a new slice. The original slice may or may not be modified depending on capacity.',
      },
    ],
  },
  {
    id: 'error-handling',
    title: 'Error Handling Patterns',
    description: 'Master Go\'s error handling philosophy and patterns.',
    category: 'functions',
    difficulty: 'intermediate',
    duration: '20 min',
    content: `# Error Handling in Go

Go takes a unique approach to error handling – no exceptions, no try/catch. Instead, errors are values that you handle explicitly.

## The error Interface

The built-in \`error\` interface has a single method: \`Error() string\`

## Custom Errors

Create your own error types for richer error information.

## Wrapping Errors

Go 1.13+ introduced error wrapping with \`fmt.Errorf\` and \`%w\` verb.

## Best Practices

1. Always check errors
2. Add context when propagating errors
3. Use custom error types for different error categories
4. Use \`errors.Is\` and \`errors.As\` for comparison
5. Don't ignore errors – handle or explicitly ignore with \`_\``,
    codeExample: `package main

import (
    "errors"
    "fmt"
)

// Custom error type
type ValidationError struct {
    Field   string
    Message string
}

func (e *ValidationError) Error() string {
    return fmt.Sprintf("validation error: %s - %s", 
        e.Field, e.Message)
}

// Sentinel errors
var (
    ErrNotFound   = errors.New("not found")
    ErrForbidden  = errors.New("access forbidden")
)

func findUser(id int) (string, error) {
    if id <= 0 {
        return "", &ValidationError{
            Field: "id", Message: "must be positive",
        }
    }
    if id > 100 {
        return "", fmt.Errorf("user %d: %w", id, ErrNotFound)
    }
    return "Alice", nil
}

func getUser(id int) (string, error) {
    name, err := findUser(id)
    if err != nil {
        return "", fmt.Errorf("getUser: %w", err)
    }
    return name, nil
}

func main() {
    // Normal case
    name, err := getUser(1)
    if err != nil {
        fmt.Println("Error:", err)
    } else {
        fmt.Println("Found:", name)
    }
    
    // Wrapped error check
    _, err = getUser(200)
    if errors.Is(err, ErrNotFound) {
        fmt.Println("User not found (wrapped)")
    }
    
    // Custom error type check
    _, err = getUser(-1)
    var valErr *ValidationError
    if errors.As(err, &valErr) {
        fmt.Printf("Validation error on field '%s': %s\\n", 
            valErr.Field, valErr.Message)
    }
    
    fmt.Println("\\nFull error chain:", err)
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What function checks if an error matches a specific error value in Go 1.13+?',
        options: ['errors.Match', 'errors.Is', 'errors.Equal', 'errors.Check'],
        correctAnswer: 1,
        explanation: 'errors.Is() checks if any error in the chain matches a specific error value.',
      },
    ],
  },
  {
    id: 'pointers',
    title: 'Pointers in Go',
    description: 'Understand pointers, references, and memory in Go.',
    category: 'basics',
    difficulty: 'beginner',
    duration: '15 min',
    content: `# Pointers in Go

Pointers hold the memory address of a value. Go has pointers but no pointer arithmetic, making them safer than in C/C++.

## Why Pointers?

- Modify values in functions (pass by reference)
- Avoid copying large structs
- Enable shared state
- Required for some data structures

## Key Operators

- \`&\` – Address-of operator (get pointer to value)
- \`*\` – Dereference operator (get value from pointer)

## Important Notes

- No pointer arithmetic in Go
- Zero value of a pointer is \`nil\`
- Go automatically handles \`&\` and \`*\` for method calls`,
    codeExample: `package main

import "fmt"

// Modify value through pointer
func doubleValue(n *int) {
    *n = *n * 2
}

type User struct {
    Name  string
    Email string
    Age   int
}

// Pointer receiver method
func (u *User) Birthday() {
    u.Age++
}

func (u User) Greet() string {
    return fmt.Sprintf("Hi, I'm %s!", u.Name)
}

// Return pointer to local variable (safe in Go)
func newUser(name, email string, age int) *User {
    return &User{
        Name:  name,
        Email: email,
        Age:   age,
    }
}

func main() {
    // Basic pointer
    x := 42
    p := &x
    fmt.Printf("Value: %d, Pointer: %p\\n", x, p)
    fmt.Printf("Dereferenced: %d\\n", *p)
    
    // Modify through pointer
    *p = 100
    fmt.Printf("x is now: %d\\n", x)
    
    // Pointer in function
    num := 5
    fmt.Printf("Before: %d\\n", num)
    doubleValue(&num)
    fmt.Printf("After doubleValue: %d\\n", num)
    
    // Struct pointer
    user := newUser("Alice", "alice@go.dev", 28)
    fmt.Println(user.Greet())
    
    user.Birthday()
    fmt.Printf("%s is now %d\\n", user.Name, user.Age)
    
    // Nil pointer check
    var ptr *int
    if ptr == nil {
        fmt.Println("Pointer is nil")
    }
}`,
    quiz: [
      {
        id: 'q1',
        question: 'What operator gets the address of a variable?',
        options: ['*', '&', '->', '@'],
        correctAnswer: 1,
        explanation: 'The & operator returns the memory address (pointer) of a variable.',
      },
    ],
  },
];

export const challenges: Challenge[] = [
  {
    id: 'fizzbuzz',
    title: 'FizzBuzz',
    description: 'Write a function that returns "Fizz" for multiples of 3, "Buzz" for multiples of 5, "FizzBuzz" for multiples of both, and the number as a string otherwise.',
    difficulty: 'easy',
    category: 'basics',
    starterCode: `package main

import "fmt"

func fizzBuzz(n int) string {
    // Your code here
    return ""
}

func main() {
    for i := 1; i <= 20; i++ {
        fmt.Println(fizzBuzz(i))
    }
}`,
    testCases: [
      { input: '3', expected: 'Fizz', description: 'Multiple of 3' },
      { input: '5', expected: 'Buzz', description: 'Multiple of 5' },
      { input: '15', expected: 'FizzBuzz', description: 'Multiple of both' },
      { input: '7', expected: '7', description: 'Neither' },
    ],
    hints: ['Use the modulo operator %', 'Check for FizzBuzz (divisible by both) first'],
    solution: `func fizzBuzz(n int) string {
    if n%15 == 0 {
        return "FizzBuzz"
    } else if n%3 == 0 {
        return "Fizz"
    } else if n%5 == 0 {
        return "Buzz"
    }
    return fmt.Sprintf("%d", n)
}`,
  },
  {
    id: 'reverse-string',
    title: 'Reverse String',
    description: 'Write a function that reverses a string. Handle Unicode characters correctly using runes.',
    difficulty: 'easy',
    category: 'basics',
    starterCode: `package main

import "fmt"

func reverseString(s string) string {
    // Your code here
    return ""
}

func main() {
    fmt.Println(reverseString("Hello, Go!"))
    fmt.Println(reverseString("世界"))
}`,
    testCases: [
      { input: 'Hello', expected: 'olleH', description: 'Simple string' },
      { input: 'Go', expected: 'oG', description: 'Short string' },
      { input: '', expected: '', description: 'Empty string' },
    ],
    hints: ['Convert string to []rune for Unicode support', 'Swap characters from both ends'],
    solution: `func reverseString(s string) string {
    runes := []rune(s)
    for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
        runes[i], runes[j] = runes[j], runes[i]
    }
    return string(runes)
}`,
  },
  {
    id: 'two-sum',
    title: 'Two Sum',
    description: 'Given an array of integers and a target, return indices of two numbers that add up to the target.',
    difficulty: 'medium',
    category: 'basics',
    starterCode: `package main

import "fmt"

func twoSum(nums []int, target int) (int, int) {
    // Your code here
    return -1, -1
}

func main() {
    i, j := twoSum([]int{2, 7, 11, 15}, 9)
    fmt.Printf("Indices: %d, %d\\n", i, j)
}`,
    testCases: [
      { input: '[2,7,11,15], 9', expected: '0, 1', description: 'Basic case' },
      { input: '[3,2,4], 6', expected: '1, 2', description: 'Not adjacent' },
    ],
    hints: ['Use a map to store seen values and their indices', 'For each number, check if target-number exists in the map'],
    solution: `func twoSum(nums []int, target int) (int, int) {
    seen := make(map[int]int)
    for i, n := range nums {
        if j, ok := seen[target-n]; ok {
            return j, i
        }
        seen[n] = i
    }
    return -1, -1
}`,
  },
  {
    id: 'linked-list',
    title: 'Implement a Stack',
    description: 'Implement a stack data structure with Push, Pop, and Peek operations using a slice.',
    difficulty: 'medium',
    category: 'structs',
    starterCode: `package main

import "fmt"

type Stack struct {
    // Define fields
}

func NewStack() *Stack {
    // Your code here
    return nil
}

func (s *Stack) Push(val int) {
    // Your code here
}

func (s *Stack) Pop() (int, bool) {
    // Your code here
    return 0, false
}

func (s *Stack) Peek() (int, bool) {
    // Your code here
    return 0, false
}

func (s *Stack) Size() int {
    // Your code here
    return 0
}

func main() {
    s := NewStack()
    s.Push(1)
    s.Push(2)
    s.Push(3)
    fmt.Println(s.Peek())
    fmt.Println(s.Pop())
    fmt.Println(s.Size())
}`,
    testCases: [
      { input: 'Push 1,2,3 then Pop', expected: '3', description: 'LIFO order' },
      { input: 'Push 1,2,3 then Size', expected: '3', description: 'Correct size' },
      { input: 'Pop on empty', expected: 'false', description: 'Empty stack handling' },
    ],
    hints: ['Use a slice as the underlying data structure', 'Pop removes from the end of the slice'],
    solution: `type Stack struct {
    items []int
}

func NewStack() *Stack {
    return &Stack{items: []int{}}
}

func (s *Stack) Push(val int) {
    s.items = append(s.items, val)
}

func (s *Stack) Pop() (int, bool) {
    if len(s.items) == 0 {
        return 0, false
    }
    val := s.items[len(s.items)-1]
    s.items = s.items[:len(s.items)-1]
    return val, true
}`,
  },
  {
    id: 'concurrent-counter',
    title: 'Thread-Safe Counter',
    description: 'Implement a thread-safe counter using sync.Mutex that can handle concurrent increments.',
    difficulty: 'hard',
    category: 'concurrency',
    starterCode: `package main

import (
    "fmt"
    "sync"
)

type SafeCounter struct {
    // Define fields
}

func NewSafeCounter() *SafeCounter {
    // Your code here
    return nil
}

func (c *SafeCounter) Increment() {
    // Your code here
}

func (c *SafeCounter) Value() int {
    // Your code here
    return 0
}

func main() {
    counter := NewSafeCounter()
    var wg sync.WaitGroup
    
    for i := 0; i < 1000; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            counter.Increment()
        }()
    }
    
    wg.Wait()
    fmt.Println("Final count:", counter.Value())
}`,
    testCases: [
      { input: '1000 concurrent increments', expected: '1000', description: 'Thread safety' },
    ],
    hints: ['Use sync.Mutex to protect shared state', 'Lock before reading or writing, unlock after'],
    solution: `type SafeCounter struct {
    mu    sync.Mutex
    count int
}

func NewSafeCounter() *SafeCounter {
    return &SafeCounter{}
}

func (c *SafeCounter) Increment() {
    c.mu.Lock()
    defer c.mu.Unlock()
    c.count++
}

func (c *SafeCounter) Value() int {
    c.mu.Lock()
    defer c.mu.Unlock()
    return c.count
}`,
  },
  {
    id: 'word-frequency',
    title: 'Word Frequency Counter',
    description: 'Count the frequency of each word in a given text and return the top N most common words.',
    difficulty: 'easy',
    category: 'basics',
    starterCode: `package main

import (
    "fmt"
    "strings"
)

func wordFrequency(text string) map[string]int {
    // Your code here
    return nil
}

func main() {
    text := "the quick brown fox jumps over the lazy dog the fox"
    freq := wordFrequency(text)
    for word, count := range freq {
        fmt.Printf("%s: %d\\n", word, count)
    }
}`,
    testCases: [
      { input: '"the the the"', expected: '{"the": 3}', description: 'Single word repeated' },
      { input: '"a b a"', expected: '{"a": 2, "b": 1}', description: 'Multiple words' },
    ],
    hints: ['Use strings.Fields to split text into words', 'Use a map[string]int to count occurrences'],
    solution: `func wordFrequency(text string) map[string]int {
    freq := make(map[string]int)
    words := strings.Fields(strings.ToLower(text))
    for _, word := range words {
        freq[word]++
    }
    return freq
}`,
  },
  {
    id: 'greeting-generator',
    title: 'Interactive Greeting Generator',
    description: 'Build a program that reads the user\'s name and age, then generates a personalized greeting with their birth year.',
    difficulty: 'easy',
    category: 'basics',
    starterCode: `package main

import "fmt"

func main() {
    // 1. Read the user's name
    var name string
    fmt.Print("Enter your name: ")
    fmt.Scan(&name)

    // 2. Read the user's age
    var age int
    fmt.Print("Enter your age: ")
    fmt.Scan(&age)

    // 3. Calculate birth year
    // Your code here

    // 4. Print personalized greeting
    // Your code here: print "Hello, NAME! You were born in YEAR."
}`,
    testCases: [
      { input: 'Alice, 25', expected: 'Hello, Alice! You were born in 1999.', description: 'Standard greeting' },
      { input: 'Bob, 30', expected: 'Hello, Bob! You were born in 1994.', description: 'Different age' },
    ],
    hints: [
      'Calculate birth year as 2024 - age',
      'Use fmt.Printf with %s for name and %d for the year',
    ],
    solution: `func main() {
    var name string
    fmt.Print("Enter your name: ")
    fmt.Scan(&name)

    var age int
    fmt.Print("Enter your age: ")
    fmt.Scan(&age)

    birthYear := 2024 - age
    fmt.Printf("Hello, %s! You were born in %d.\\n", name, birthYear)
}`,
  },
  {
    id: 'temperature-converter',
    title: 'Temperature Converter',
    description: 'Read a temperature in Celsius from the user and convert it to Fahrenheit. Formula: F = C × 9/5 + 32',
    difficulty: 'easy',
    category: 'basics',
    starterCode: `package main

import "fmt"

func celsiusToFahrenheit(c float64) float64 {
    // Your code here
    return 0
}

func main() {
    var celsius float64
    fmt.Print("Enter temperature in Celsius: ")
    fmt.Scan(&celsius)

    // Convert and print the result
    // Your code here
}`,
    testCases: [
      { input: '100', expected: '212.00', description: 'Boiling point' },
      { input: '0', expected: '32.00', description: 'Freezing point' },
      { input: '37', expected: '98.60', description: 'Body temperature' },
    ],
    hints: [
      'Formula: fahrenheit = celsius * 9.0 / 5.0 + 32.0',
      'Use fmt.Printf("%.2f°C = %.2f°F\\n", celsius, fahrenheit) for output',
    ],
    solution: `func celsiusToFahrenheit(c float64) float64 {
    return c * 9.0 / 5.0 + 32.0
}

func main() {
    var celsius float64
    fmt.Print("Enter temperature in Celsius: ")
    fmt.Scan(&celsius)
    
    f := celsiusToFahrenheit(celsius)
    fmt.Printf("%.2f°C = %.2f°F\\n", celsius, f)
}`,
  },
];

export const projects: Project[] = [
  {
    id: 'cli-todo',
    title: 'CLI Todo App',
    description: 'Build a command-line todo application with add, list, complete, and delete functionality. Data persists to a JSON file.',
    difficulty: 'beginner',
    topics: ['CLI', 'File I/O', 'JSON', 'Structs'],
    steps: [
      'Define a Todo struct with ID, Title, Completed, and CreatedAt fields',
      'Implement functions to load/save todos from a JSON file',
      'Add command-line argument parsing for add, list, complete, delete',
      'Format output with colors using ANSI codes',
      'Add error handling for all file operations',
    ],
    starterCode: `package main

import (
    "encoding/json"
    "fmt"
    "os"
    "time"
)

type Todo struct {
    ID        int       \`json:"id"\`
    Title     string    \`json:"title"\`
    Completed bool      \`json:"completed"\`
    CreatedAt time.Time \`json:"created_at"\`
}

const filename = "todos.json"

func loadTodos() ([]Todo, error) {
    data, err := os.ReadFile(filename)
    if err != nil {
        return []Todo{}, nil
    }
    var todos []Todo
    return todos, json.Unmarshal(data, &todos)
}

func saveTodos(todos []Todo) error {
    data, err := json.MarshalIndent(todos, "", "  ")
    if err != nil {
        return err
    }
    return os.WriteFile(filename, data, 0644)
}

func main() {
    // Parse os.Args and implement commands
    fmt.Println("Todo CLI App")
}`,
    image: '📝',
  },
  {
    id: 'url-shortener',
    title: 'URL Shortener',
    description: 'Build a URL shortening service with a REST API and web interface. Features include custom short codes, click tracking, and expiration.',
    difficulty: 'intermediate',
    topics: ['HTTP Server', 'REST API', 'Maps', 'Concurrency'],
    steps: [
      'Set up an HTTP server with net/http',
      'Create an in-memory store for URL mappings',
      'Implement POST /shorten endpoint to create short URLs',
      'Implement GET /{code} endpoint for redirects',
      'Add click tracking and statistics endpoint',
      'Create a simple HTML frontend',
    ],
    starterCode: `package main

import (
    "crypto/rand"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "net/http"
    "sync"
    "time"
)

type URL struct {
    Original  string    \`json:"original"\`
    Short     string    \`json:"short"\`
    Clicks    int       \`json:"clicks"\`
    CreatedAt time.Time \`json:"created_at"\`
}

type URLStore struct {
    mu   sync.RWMutex
    urls map[string]*URL
}

func generateCode() string {
    b := make([]byte, 4)
    rand.Read(b)
    return hex.EncodeToString(b)
}

func main() {
    store := &URLStore{urls: make(map[string]*URL)}
    _ = store
    fmt.Println("URL Shortener running on :8080")
    http.ListenAndServe(":8080", nil)
}`,
    image: '🔗',
  },
  {
    id: 'chat-server',
    title: 'Real-Time Chat Server',
    description: 'Build a WebSocket-based chat server supporting multiple rooms, user nicknames, and message broadcasting.',
    difficulty: 'advanced',
    topics: ['WebSockets', 'Goroutines', 'Channels', 'Concurrency'],
    steps: [
      'Set up WebSocket server using gorilla/websocket',
      'Implement a Hub to manage connected clients',
      'Create chat rooms with join/leave functionality',
      'Broadcast messages to all clients in a room',
      'Add user nicknames and timestamps',
      'Handle disconnections gracefully',
    ],
    starterCode: `package main

import (
    "fmt"
    "log"
    "sync"
)

type Client struct {
    ID       string
    Nickname string
    Room     string
    Send     chan Message
}

type Message struct {
    Type     string \`json:"type"\`
    Content  string \`json:"content"\`
    Sender   string \`json:"sender"\`
    Room     string \`json:"room"\`
}

type Hub struct {
    mu       sync.RWMutex
    clients  map[string]*Client
    rooms    map[string]map[string]*Client
    broadcast chan Message
}

func NewHub() *Hub {
    return &Hub{
        clients:   make(map[string]*Client),
        rooms:     make(map[string]map[string]*Client),
        broadcast: make(chan Message),
    }
}

func main() {
    hub := NewHub()
    _ = hub
    log.Println("Chat server starting...")
    fmt.Println("Chat server on :8080")
}`,
    image: '💬',
  },
  {
    id: 'rest-api-project',
    title: 'Blog API with Database',
    description: 'Build a full-featured blog REST API with CRUD operations, authentication, pagination, and SQLite database.',
    difficulty: 'advanced',
    topics: ['REST API', 'Database', 'Authentication', 'Middleware'],
    steps: [
      'Design the database schema for posts and users',
      'Set up SQLite with database/sql',
      'Implement CRUD endpoints for blog posts',
      'Add JWT-based authentication',
      'Implement pagination and filtering',
      'Add middleware for logging and auth',
      'Write integration tests',
    ],
    starterCode: `package main

import (
    "encoding/json"
    "fmt"
    "net/http"
    "time"
)

type Post struct {
    ID        int       \`json:"id"\`
    Title     string    \`json:"title"\`
    Content   string    \`json:"content"\`
    Author    string    \`json:"author"\`
    CreatedAt time.Time \`json:"created_at"\`
    UpdatedAt time.Time \`json:"updated_at"\`
}

type APIResponse struct {
    Success bool        \`json:"success"\`
    Data    interface{} \`json:"data,omitempty"\`
    Error   string      \`json:"error,omitempty"\`
}

func jsonResponse(w http.ResponseWriter, status int, data interface{}) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(status)
    json.NewEncoder(w).Encode(data)
}

func main() {
    fmt.Println("Blog API running on :8080")
    http.ListenAndServe(":8080", nil)
}`,
    image: '📰',
  },
];
