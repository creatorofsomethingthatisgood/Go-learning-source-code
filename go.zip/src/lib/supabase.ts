/**
 * Supabase Database Integration
 * 
 * SETUP INSTRUCTIONS:
 * 
 * 1. Go to https://supabase.com and create a free account
 * 
 * 2. Create a new project (remember your database password)
 * 
 * 3. Go to Project Settings > API and copy:
 *    - Project URL (e.g., https://xxxxx.supabase.co)
 *    - anon/public key
 * 
 * 4. Replace the values below with your credentials:
 */

// ═══════════════════════════════════════════════════════════════════════════
// REPLACE THESE WITH YOUR SUPABASE CREDENTIALS
// ═══════════════════════════════════════════════════════════════════════════
const SUPABASE_URL = 'YOUR_SUPABASE_URL';  // e.g., 'https://abcdefg.supabase.co'
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';  // The long key starting with 'eyJ...'
// ═══════════════════════════════════════════════════════════════════════════

/**
 * 5. In Supabase SQL Editor, run this to create the tables:
 * 
 * ```sql
 * -- Users table (extends Supabase auth.users)
 * CREATE TABLE IF NOT EXISTS profiles (
 *   id UUID REFERENCES auth.users(id) PRIMARY KEY,
 *   name TEXT NOT NULL,
 *   avatar TEXT,
 *   created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
 * );
 * 
 * -- Progress tracking table
 * CREATE TABLE IF NOT EXISTS user_progress (
 *   id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
 *   user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
 *   completed_lessons TEXT[] DEFAULT '{}',
 *   completed_challenges TEXT[] DEFAULT '{}',
 *   quiz_scores JSONB DEFAULT '{}',
 *   current_streak INTEGER DEFAULT 0,
 *   total_xp INTEGER DEFAULT 0,
 *   last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
 *   UNIQUE(user_id)
 * );
 * 
 * -- Enable Row Level Security
 * ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
 * ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
 * 
 * -- Policies: users can only read/write their own data
 * CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
 * CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
 * CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
 * 
 * CREATE POLICY "Users can view own progress" ON user_progress FOR SELECT USING (auth.uid() = user_id);
 * CREATE POLICY "Users can update own progress" ON user_progress FOR UPDATE USING (auth.uid() = user_id);
 * CREATE POLICY "Users can insert own progress" ON user_progress FOR INSERT WITH CHECK (auth.uid() = user_id);
 * 
 * -- Auto-create profile and progress on signup
 * CREATE OR REPLACE FUNCTION handle_new_user()
 * RETURNS TRIGGER AS $$
 * BEGIN
 *   INSERT INTO profiles (id, name, avatar)
 *   VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', 'Gopher'), 
 *           UPPER(LEFT(COALESCE(NEW.raw_user_meta_data->>'name', 'G'), 1)));
 *   INSERT INTO user_progress (user_id) VALUES (NEW.id);
 *   RETURN NEW;
 * END;
 * $$ LANGUAGE plpgsql SECURITY DEFINER;
 * 
 * CREATE OR REPLACE TRIGGER on_auth_user_created
 *   AFTER INSERT ON auth.users
 *   FOR EACH ROW EXECUTE FUNCTION handle_new_user();
 * ```
 * 
 * 6. In Supabase Dashboard > Authentication > Providers, enable Email provider
 */

export interface SupabaseUser {
  id: string;
  email: string;
  name: string;
  avatar: string;
}

export interface SupabaseProgress {
  completed_lessons: string[];
  completed_challenges: string[];
  quiz_scores: Record<string, number>;
  current_streak: number;
  total_xp: number;
}

// Check if Supabase is configured
export const isSupabaseConfigured = (): boolean => {
  const url = SUPABASE_URL as string;
  const key = SUPABASE_ANON_KEY as string;
  return url !== 'YOUR_SUPABASE_URL' && 
         key !== 'YOUR_SUPABASE_ANON_KEY' &&
         url.includes('supabase.co');
};

// Simple fetch wrapper for Supabase REST API
const supabaseFetch = async (
  endpoint: string, 
  options: RequestInit & { headers?: Record<string, string> } = {}
): Promise<Response> => {
  const url = `${SUPABASE_URL}${endpoint}`;
  const authHeader = options.headers?.['Authorization'];
  const token = authHeader ? authHeader.replace('Bearer ', '') : SUPABASE_ANON_KEY;
  
  return fetch(url, {
    ...options,
    headers: {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
      ...options.headers,
    },
  });
};

// ═══════════════════════════════════════════════════════════════════════════
// AUTH FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

export const supabaseSignUp = async (
  email: string, 
  password: string, 
  name: string
): Promise<{ user: SupabaseUser | null; error: string | null; session: any }> => {
  try {
    const res = await supabaseFetch('/auth/v1/signup', {
      method: 'POST',
      body: JSON.stringify({ 
        email, 
        password,
        data: { name }  // This goes into raw_user_meta_data
      }),
    });

    const data = await res.json();

    if (data.error || !data.user) {
      return { user: null, error: data.error?.message || data.msg || 'Signup failed', session: null };
    }

    return { 
      user: {
        id: data.user.id,
        email: data.user.email,
        name: name,
        avatar: name.charAt(0).toUpperCase(),
      },
      error: null,
      session: data.session || data.access_token ? data : null,
    };
  } catch (err) {
    return { user: null, error: 'Network error. Please try again.', session: null };
  }
};

export const supabaseSignIn = async (
  email: string, 
  password: string
): Promise<{ user: SupabaseUser | null; error: string | null; session: any }> => {
  try {
    const res = await supabaseFetch('/auth/v1/token?grant_type=password', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (data.error || !data.access_token) {
      return { user: null, error: data.error_description || data.msg || 'Invalid credentials', session: null };
    }

    // Fetch profile
    const profileRes = await supabaseFetch(`/rest/v1/profiles?id=eq.${data.user.id}&select=*`, {
      headers: { 'Authorization': `Bearer ${data.access_token}` },
    });
    const profiles = await profileRes.json();
    const profile = profiles[0] || {};

    return {
      user: {
        id: data.user.id,
        email: data.user.email,
        name: profile.name || email.split('@')[0],
        avatar: profile.avatar || email.charAt(0).toUpperCase(),
      },
      error: null,
      session: data,
    };
  } catch (err) {
    return { user: null, error: 'Network error. Please try again.', session: null };
  }
};

export const supabaseSignOut = async (accessToken: string): Promise<void> => {
  try {
    await supabaseFetch('/auth/v1/logout', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });
  } catch {
    // Ignore errors on logout
  }
};

export const supabaseGetSession = async (): Promise<{ user: SupabaseUser | null; session: any }> => {
  const stored = localStorage.getItem('gomaster-supabase-session');
  if (!stored) return { user: null, session: null };

  try {
    const session = JSON.parse(stored);
    if (!session.access_token) return { user: null, session: null };

    // Verify token is still valid
    const res = await supabaseFetch('/auth/v1/user', {
      headers: { 'Authorization': `Bearer ${session.access_token}` },
    });

    if (!res.ok) {
      // Try refresh token
      if (session.refresh_token) {
        const refreshRes = await supabaseFetch('/auth/v1/token?grant_type=refresh_token', {
          method: 'POST',
          body: JSON.stringify({ refresh_token: session.refresh_token }),
        });
        const newSession = await refreshRes.json();
        if (newSession.access_token) {
          localStorage.setItem('gomaster-supabase-session', JSON.stringify(newSession));
          return supabaseGetSession(); // Retry with new token
        }
      }
      localStorage.removeItem('gomaster-supabase-session');
      return { user: null, session: null };
    }

    const userData = await res.json();
    
    // Fetch profile
    const profileRes = await supabaseFetch(`/rest/v1/profiles?id=eq.${userData.id}&select=*`, {
      headers: { 'Authorization': `Bearer ${session.access_token}` },
    });
    const profiles = await profileRes.json();
    const profile = profiles[0] || {};

    return {
      user: {
        id: userData.id,
        email: userData.email,
        name: profile.name || userData.email?.split('@')[0] || 'User',
        avatar: profile.avatar || 'U',
      },
      session,
    };
  } catch {
    return { user: null, session: null };
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// PROGRESS FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

export const supabaseGetProgress = async (
  userId: string, 
  accessToken: string
): Promise<SupabaseProgress> => {
  const defaultProgress: SupabaseProgress = {
    completed_lessons: [],
    completed_challenges: [],
    quiz_scores: {},
    current_streak: 0,
    total_xp: 0,
  };

  try {
    const res = await supabaseFetch(`/rest/v1/user_progress?user_id=eq.${userId}&select=*`, {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });
    const data = await res.json();
    
    if (data[0]) {
      return {
        completed_lessons: data[0].completed_lessons || [],
        completed_challenges: data[0].completed_challenges || [],
        quiz_scores: data[0].quiz_scores || {},
        current_streak: data[0].current_streak || 0,
        total_xp: data[0].total_xp || 0,
      };
    }
    return defaultProgress;
  } catch {
    return defaultProgress;
  }
};

export const supabaseUpdateProgress = async (
  userId: string, 
  accessToken: string, 
  progress: SupabaseProgress
): Promise<boolean> => {
  try {
    const res = await supabaseFetch(`/rest/v1/user_progress?user_id=eq.${userId}`, {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${accessToken}` },
      body: JSON.stringify({
        completed_lessons: progress.completed_lessons,
        completed_challenges: progress.completed_challenges,
        quiz_scores: progress.quiz_scores,
        current_streak: progress.current_streak,
        total_xp: progress.total_xp,
        last_activity: new Date().toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
};

export const supabaseCompleteLesson = async (
  userId: string, 
  accessToken: string, 
  lessonId: string,
  currentProgress: SupabaseProgress
): Promise<SupabaseProgress> => {
  if (currentProgress.completed_lessons.includes(lessonId)) {
    return currentProgress;
  }

  const newProgress: SupabaseProgress = {
    ...currentProgress,
    completed_lessons: [...currentProgress.completed_lessons, lessonId],
    total_xp: currentProgress.total_xp + 50,
    current_streak: currentProgress.current_streak + 1,
  };

  await supabaseUpdateProgress(userId, accessToken, newProgress);
  return newProgress;
};

export const supabaseCompleteChallenge = async (
  userId: string, 
  accessToken: string, 
  challengeId: string,
  currentProgress: SupabaseProgress
): Promise<SupabaseProgress> => {
  if (currentProgress.completed_challenges.includes(challengeId)) {
    return currentProgress;
  }

  const newProgress: SupabaseProgress = {
    ...currentProgress,
    completed_challenges: [...currentProgress.completed_challenges, challengeId],
    total_xp: currentProgress.total_xp + 100,
  };

  await supabaseUpdateProgress(userId, accessToken, newProgress);
  return newProgress;
};

export const supabaseSaveQuizScore = async (
  userId: string, 
  accessToken: string, 
  lessonId: string,
  score: number,
  currentProgress: SupabaseProgress
): Promise<SupabaseProgress> => {
  const newProgress: SupabaseProgress = {
    ...currentProgress,
    quiz_scores: { ...currentProgress.quiz_scores, [lessonId]: score },
    total_xp: currentProgress.total_xp + Math.round(score * 0.5),
  };

  await supabaseUpdateProgress(userId, accessToken, newProgress);
  return newProgress;
};
