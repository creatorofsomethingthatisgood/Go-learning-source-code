import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  isSupabaseConfigured,
  supabaseSignUp,
  supabaseSignIn,
  supabaseSignOut,
  supabaseGetSession,
  supabaseGetProgress,
  supabaseCompleteLesson,
  supabaseCompleteChallenge,
  supabaseSaveQuizScore,
  type SupabaseProgress,
} from '../lib/supabase';

export type Page = 'home' | 'lessons' | 'lesson' | 'practice' | 'projects' | 'auth';

interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  joinedAt: string;
}

interface Progress {
  completedLessons: string[];
  completedChallenges: string[];
  quizScores: Record<string, number>;
  currentStreak: number;
  totalXP: number;
}

interface AppState {
  page: Page;
  selectedLessonId: string | null;
  selectedChallengeId: string | null;
  darkMode: boolean;
  sidebarOpen: boolean;
  user: User | null;
  progress: Progress;
  isAuthenticated: boolean;
  isLoading: boolean;
  useSupabase: boolean;
  supabaseSession: any;
}

interface AppContextType extends AppState {
  navigate: (page: Page, params?: { lessonId?: string; challengeId?: string }) => void;
  toggleDarkMode: () => void;
  toggleSidebar: () => void;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  completeLesson: (lessonId: string) => void;
  completeChallenge: (challengeId: string) => void;
  saveQuizScore: (lessonId: string, score: number) => void;
  getLessonProgress: () => number;
  getChallengeProgress: () => number;
  authError: string | null;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultProgress: Progress = {
  completedLessons: [],
  completedChallenges: [],
  quizScores: {},
  currentStreak: 0,
  totalXP: 0,
};

// Convert between Supabase and local progress formats
const fromSupabaseProgress = (sp: SupabaseProgress): Progress => ({
  completedLessons: sp.completed_lessons,
  completedChallenges: sp.completed_challenges,
  quizScores: sp.quiz_scores,
  currentStreak: sp.current_streak,
  totalXP: sp.total_xp,
});

const toSupabaseProgress = (p: Progress): SupabaseProgress => ({
  completed_lessons: p.completedLessons,
  completed_challenges: p.completedChallenges,
  quiz_scores: p.quizScores,
  current_streak: p.currentStreak,
  total_xp: p.totalXP,
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [authError, setAuthError] = useState<string | null>(null);
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('gomaster-state');
    const useSupabase = isSupabaseConfigured();
    
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          page: 'home' as Page,
          selectedLessonId: null,
          selectedChallengeId: null,
          sidebarOpen: false,
          isLoading: useSupabase, // Load session if using Supabase
          useSupabase,
          supabaseSession: null,
        };
      } catch { /* ignore */ }
    }
    return {
      page: 'home' as Page,
      selectedLessonId: null,
      selectedChallengeId: null,
      darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches,
      sidebarOpen: false,
      user: null,
      progress: defaultProgress,
      isAuthenticated: false,
      isLoading: useSupabase,
      useSupabase,
      supabaseSession: null,
    };
  });

  // Restore Supabase session on mount
  useEffect(() => {
    if (state.useSupabase && state.isLoading) {
      supabaseGetSession().then(async ({ user, session }) => {
        if (user && session) {
          const progress = await supabaseGetProgress(user.id, session.access_token);
          setState(prev => ({
            ...prev,
            user: { ...user, joinedAt: new Date().toISOString() },
            progress: fromSupabaseProgress(progress),
            isAuthenticated: true,
            isLoading: false,
            supabaseSession: session,
          }));
        } else {
          setState(prev => ({ ...prev, isLoading: false }));
        }
      });
    }
  }, []);

  // Save state to localStorage
  useEffect(() => {
    const { page, selectedLessonId, selectedChallengeId, sidebarOpen, isLoading, supabaseSession, ...toSave } = state;
    localStorage.setItem('gomaster-state', JSON.stringify(toSave));
  }, [state]);

  // Dark mode
  useEffect(() => {
    if (state.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.darkMode]);

  const navigate = useCallback((page: Page, params?: { lessonId?: string; challengeId?: string }) => {
    setState(prev => ({
      ...prev,
      page,
      selectedLessonId: params?.lessonId ?? null,
      selectedChallengeId: params?.challengeId ?? null,
      sidebarOpen: false,
    }));
    window.scrollTo(0, 0);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setState(prev => ({ ...prev, darkMode: !prev.darkMode }));
  }, []);

  const toggleSidebar = useCallback(() => {
    setState(prev => ({ ...prev, sidebarOpen: !prev.sidebarOpen }));
  }, []);

  // ═══════════════════════════════════════════════════════════════════════════
  // AUTH: Supabase or localStorage
  // ═══════════════════════════════════════════════════════════════════════════

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    setAuthError(null);

    if (state.useSupabase) {
      const { user, session, error } = await supabaseSignIn(email, password);
      if (error || !user || !session) {
        setAuthError(error || 'Login failed');
        return false;
      }
      localStorage.setItem('gomaster-supabase-session', JSON.stringify(session));
      const progress = await supabaseGetProgress(user.id, session.access_token);
      setState(prev => ({
        ...prev,
        user: { ...user, joinedAt: new Date().toISOString() },
        progress: fromSupabaseProgress(progress),
        isAuthenticated: true,
        supabaseSession: session,
      }));
      return true;
    } else {
      // localStorage fallback
      const users = JSON.parse(localStorage.getItem('gomaster-users') || '[]');
      const user = users.find((u: any) => u.email === email);
      if (user) {
        const progress = JSON.parse(localStorage.getItem(`gomaster-progress-${user.id}`) || 'null') || defaultProgress;
        setState(prev => ({ ...prev, user, progress, isAuthenticated: true }));
        return true;
      }
      setAuthError('Account not found. Please sign up first.');
      return false;
    }
  }, [state.useSupabase]);

  const signup = useCallback(async (name: string, email: string, password: string): Promise<boolean> => {
    setAuthError(null);

    if (state.useSupabase) {
      const { user, session, error } = await supabaseSignUp(email, password, name);
      if (error || !user) {
        setAuthError(error || 'Signup failed');
        return false;
      }
      if (session) {
        localStorage.setItem('gomaster-supabase-session', JSON.stringify(session));
        setState(prev => ({
          ...prev,
          user: { ...user, joinedAt: new Date().toISOString() },
          progress: defaultProgress,
          isAuthenticated: true,
          supabaseSession: session,
        }));
      } else {
        // Email confirmation may be required
        setAuthError('Please check your email to confirm your account.');
        return false;
      }
      return true;
    } else {
      // localStorage fallback
      const users = JSON.parse(localStorage.getItem('gomaster-users') || '[]');
      if (users.find((u: any) => u.email === email)) {
        setAuthError('An account with this email already exists.');
        return false;
      }
      
      const newUser: User = {
        id: crypto.randomUUID(),
        name,
        email,
        avatar: name.charAt(0).toUpperCase(),
        joinedAt: new Date().toISOString(),
      };
      users.push(newUser);
      localStorage.setItem('gomaster-users', JSON.stringify(users));
      setState(prev => ({ ...prev, user: newUser, progress: defaultProgress, isAuthenticated: true }));
      return true;
    }
  }, [state.useSupabase]);

  const logout = useCallback(() => {
    if (state.useSupabase && state.supabaseSession) {
      supabaseSignOut(state.supabaseSession.access_token);
      localStorage.removeItem('gomaster-supabase-session');
    } else if (state.user) {
      localStorage.setItem(`gomaster-progress-${state.user.id}`, JSON.stringify(state.progress));
    }
    setState(prev => ({
      ...prev,
      user: null,
      progress: defaultProgress,
      isAuthenticated: false,
      supabaseSession: null,
      page: 'home' as Page,
    }));
  }, [state.useSupabase, state.supabaseSession, state.user, state.progress]);

  // ═══════════════════════════════════════════════════════════════════════════
  // PROGRESS: Supabase or localStorage
  // ═══════════════════════════════════════════════════════════════════════════

  const completeLesson = useCallback((lessonId: string) => {
    setState(prev => {
      if (prev.progress.completedLessons.includes(lessonId)) return prev;
      
      const newProgress = {
        ...prev.progress,
        completedLessons: [...prev.progress.completedLessons, lessonId],
        totalXP: prev.progress.totalXP + 50,
        currentStreak: prev.progress.currentStreak + 1,
      };

      // Async save to Supabase or localStorage
      if (prev.useSupabase && prev.user && prev.supabaseSession) {
        supabaseCompleteLesson(
          prev.user.id,
          prev.supabaseSession.access_token,
          lessonId,
          toSupabaseProgress(prev.progress)
        );
      } else if (prev.user) {
        localStorage.setItem(`gomaster-progress-${prev.user.id}`, JSON.stringify(newProgress));
      }

      return { ...prev, progress: newProgress };
    });
  }, []);

  const completeChallenge = useCallback((challengeId: string) => {
    setState(prev => {
      if (prev.progress.completedChallenges.includes(challengeId)) return prev;
      
      const newProgress = {
        ...prev.progress,
        completedChallenges: [...prev.progress.completedChallenges, challengeId],
        totalXP: prev.progress.totalXP + 100,
      };

      if (prev.useSupabase && prev.user && prev.supabaseSession) {
        supabaseCompleteChallenge(
          prev.user.id,
          prev.supabaseSession.access_token,
          challengeId,
          toSupabaseProgress(prev.progress)
        );
      } else if (prev.user) {
        localStorage.setItem(`gomaster-progress-${prev.user.id}`, JSON.stringify(newProgress));
      }

      return { ...prev, progress: newProgress };
    });
  }, []);

  const saveQuizScore = useCallback((lessonId: string, score: number) => {
    setState(prev => {
      const newProgress = {
        ...prev.progress,
        quizScores: { ...prev.progress.quizScores, [lessonId]: score },
        totalXP: prev.progress.totalXP + Math.round(score * 0.5),
      };

      if (prev.useSupabase && prev.user && prev.supabaseSession) {
        supabaseSaveQuizScore(
          prev.user.id,
          prev.supabaseSession.access_token,
          lessonId,
          score,
          toSupabaseProgress(prev.progress)
        );
      } else if (prev.user) {
        localStorage.setItem(`gomaster-progress-${prev.user.id}`, JSON.stringify(newProgress));
      }

      return { ...prev, progress: newProgress };
    });
  }, []);

  const getLessonProgress = useCallback(() => {
    return state.progress.completedLessons.length;
  }, [state.progress.completedLessons.length]);

  const getChallengeProgress = useCallback(() => {
    return state.progress.completedChallenges.length;
  }, [state.progress.completedChallenges.length]);

  // Show loading state while restoring Supabase session
  if (state.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white font-bold text-xl mx-auto mb-4 animate-pulse">
            Go
          </div>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <AppContext.Provider value={{
      ...state,
      navigate,
      toggleDarkMode,
      toggleSidebar,
      login,
      signup,
      logout,
      completeLesson,
      completeChallenge,
      saveQuizScore,
      getLessonProgress,
      getChallengeProgress,
      authError,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
