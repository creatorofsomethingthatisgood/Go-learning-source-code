import { useState } from 'react';
import { projects } from '../data/lessons';
import {
  ChevronDown, ChevronUp, Copy, Check,
  FolderKanban, Tag
} from 'lucide-react';

export default function ProjectsPage() {
  const [expandedProject, setExpandedProject] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const getDifficultyColor = (d: string) => {
    if (d === 'beginner') return '#10B981';
    if (d === 'intermediate') return '#F59E0B';
    return '#EF4444';
  };

  const copyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Go <span className="gradient-text">Projects</span>
          </h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
            Build real-world applications to solidify your Go skills
          </p>
        </div>

        {/* Project Cards */}
        <div className="space-y-6 animate-fade-in stagger-1">
          {projects.map(project => {
            const isExpanded = expandedProject === project.id;

            return (
              <div
                key={project.id}
                className="rounded-2xl border overflow-hidden transition-all"
                style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
              >
                {/* Header */}
                <button
                  onClick={() => setExpandedProject(isExpanded ? null : project.id)}
                  className="w-full text-left p-6 sm:p-8 flex items-start gap-6 group"
                >
                  <div className="text-5xl">{project.image}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h2 className="text-xl font-bold group-hover:text-go-cyan transition-colors" style={{ color: 'var(--text-primary)' }}>
                        {project.title}
                      </h2>
                      <span
                        className="px-3 py-1 rounded-full text-xs font-semibold"
                        style={{
                          backgroundColor: `${getDifficultyColor(project.difficulty)}15`,
                          color: getDifficultyColor(project.difficulty)
                        }}
                      >
                        {project.difficulty}
                      </span>
                    </div>
                    <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                      {project.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {project.topics.map(topic => (
                        <span
                          key={topic}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium"
                          style={{ backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}
                        >
                          <Tag size={12} />
                          {topic}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex-shrink-0 mt-2">
                    {isExpanded ? (
                      <ChevronUp size={24} style={{ color: 'var(--text-secondary)' }} />
                    ) : (
                      <ChevronDown size={24} style={{ color: 'var(--text-secondary)' }} />
                    )}
                  </div>
                </button>

                {/* Expanded Content */}
                {isExpanded && (
                  <div className="px-6 sm:px-8 pb-8 border-t animate-fade-in" style={{ borderColor: 'var(--border-color)' }}>
                    {/* Steps */}
                    <div className="mt-6 mb-8">
                      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                        <FolderKanban size={20} className="text-go-cyan" />
                        Project Steps
                      </h3>
                      <div className="space-y-3">
                        {project.steps.map((step, i) => (
                          <div key={i} className="flex items-start gap-3">
                            <div className="w-7 h-7 rounded-full bg-go-cyan/10 text-go-cyan flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                              {i + 1}
                            </div>
                            <p className="text-sm pt-1" style={{ color: 'var(--text-secondary)' }}>{step}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Starter Code */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-lg font-semibold" style={{ color: 'var(--text-primary)' }}>
                          Starter Code
                        </h3>
                        <button
                          onClick={(e) => { e.stopPropagation(); copyCode(project.id, project.starterCode); }}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border hover:bg-go-cyan/5 transition-colors"
                          style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}
                        >
                          {copiedId === project.id ? <Check size={14} className="text-go-success" /> : <Copy size={14} />}
                          {copiedId === project.id ? 'Copied!' : 'Copy Code'}
                        </button>
                      </div>
                      <div className="rounded-xl overflow-hidden">
                        <pre className="p-6 overflow-x-auto text-sm" style={{ backgroundColor: '#1e1e2e' }}>
                          <code className="font-mono text-gray-300" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                            {project.starterCode}
                          </code>
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
