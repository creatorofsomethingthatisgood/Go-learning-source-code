import { useApp } from '../store/AppContext';
import { lessons } from '../data/lessons';
import { useState, useEffect, useRef } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-go';
import { runGoCode, detectInputCalls, type RunResult } from '../utils/goRunner';
import {
  ArrowLeft, Play, Copy, Check, ChevronRight,
  ChevronLeft, BookOpen, HelpCircle, CheckCircle2,
  XCircle, Award, RotateCcw, Terminal
} from 'lucide-react';

export default function LessonPage() {
  const { selectedLessonId, navigate, completeLesson, saveQuizScore, progress } = useApp();
  const lesson = lessons.find(l => l.id === selectedLessonId);
  const [code, setCode] = useState('');
  const [output, setOutput] = useState<RunResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'content' | 'code' | 'quiz'>('content');
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number | null>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [userInputs, setUserInputs] = useState<string[]>([]);
  const [inputPrompts, setInputPrompts] = useState<string[]>([]);
  const [showInputPanel, setShowInputPanel] = useState(false);

  useEffect(() => {
    if (lesson) {
      setCode(lesson.codeExample);
      setOutput(null);
      setQuizAnswers({});
      setQuizSubmitted(false);
      setQuizScore(null);
      setUserInputs([]);
      setInputPrompts([]);
      setShowInputPanel(false);
    }
  }, [lesson]);

  useEffect(() => {
    Prism.highlightAll();
  }, [code, activeTab]);

  if (!lesson) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-secondary)' }}>Lesson not found</p>
          <button onClick={() => navigate('lessons')} className="text-go-cyan hover:underline">
            Back to Lessons
          </button>
        </div>
      </div>
    );
  }

  const currentIndex = lessons.findIndex(l => l.id === lesson.id);
  const prevLesson = currentIndex > 0 ? lessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < lessons.length - 1 ? lessons[currentIndex + 1] : null;
  const isCompleted = progress.completedLessons.includes(lesson.id);

  const simulateRun = (providedInputs?: string[]) => {
    // First check if code needs input
    const { needsInput, prompts } = detectInputCalls(code);

    if (needsInput && !providedInputs && !showInputPanel) {
      // Show input panel instead of running
      setInputPrompts(prompts);
      setUserInputs(prompts.map(() => ''));
      setShowInputPanel(true);
      return;
    }

    setIsRunning(true);
    setOutput(null);
    setShowInputPanel(false);

    setTimeout(() => {
      const inputs = providedInputs || userInputs;
      const result = runGoCode(code, inputs.length > 0 ? inputs : undefined);
      setOutput(result);
      setIsRunning(false);
    }, 600 + Math.random() * 400);
  };

  const handleRunWithInput = () => {
    simulateRun(userInputs);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleQuizSubmit = () => {
    if (!lesson.quiz.length) return;
    
    let correct = 0;
    lesson.quiz.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) correct++;
    });
    
    const score = Math.round((correct / lesson.quiz.length) * 100);
    setQuizScore(score);
    setQuizSubmitted(true);
    saveQuizScore(lesson.id, score);
    
    if (score >= 70) {
      completeLesson(lesson.id);
    }
  };

  const resetQuiz = () => {
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(null);
  };

  const renderMarkdown = (text: string) => {
    const lines = text.split('\n');
    const elements: React.ReactElement[] = [];
    
    lines.forEach((line, i) => {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('# ')) {
        elements.push(<h1 key={i} className="text-2xl font-bold mb-4 mt-6" style={{ color: 'var(--text-primary)' }}>{trimmed.slice(2)}</h1>);
      } else if (trimmed.startsWith('## ')) {
        elements.push(<h2 key={i} className="text-xl font-bold mb-3 mt-6" style={{ color: 'var(--text-primary)' }}>{trimmed.slice(3)}</h2>);
      } else if (trimmed.startsWith('### ')) {
        elements.push(<h3 key={i} className="text-lg font-semibold mb-2 mt-4" style={{ color: 'var(--text-primary)' }}>{trimmed.slice(4)}</h3>);
      } else if (trimmed.startsWith('> ')) {
        elements.push(
          <blockquote key={i} className="border-l-4 border-go-cyan pl-4 py-2 my-4 italic" style={{ color: 'var(--text-secondary)' }}>
            {trimmed.slice(2)}
          </blockquote>
        );
      } else if (trimmed.startsWith('- **') || trimmed.startsWith('- ')) {
        const content = trimmed.slice(2);
        const boldMatch = content.match(/^\*\*(.*?)\*\*(.*)/);
        elements.push(
          <li key={i} className="flex items-start gap-2 mb-1.5 ml-4" style={{ color: 'var(--text-secondary)' }}>
            <span className="text-go-cyan mt-1.5 min-w-[6px] h-1.5 w-1.5 rounded-full bg-go-cyan inline-block" />
            {boldMatch ? (
              <span><strong style={{ color: 'var(--text-primary)' }}>{boldMatch[1]}</strong>{boldMatch[2].replace(/–\s*/, ' – ')}</span>
            ) : content}
          </li>
        );
      } else if (/^\d+\.\s/.test(trimmed)) {
        const num = trimmed.match(/^(\d+)\.\s/)?.[1];
        const content = trimmed.replace(/^\d+\.\s/, '');
        const boldMatch = content.match(/^\*\*(.*?)\*\*(.*)/);
        elements.push(
          <li key={i} className="flex items-start gap-2 mb-1.5 ml-4" style={{ color: 'var(--text-secondary)' }}>
            <span className="text-go-cyan font-semibold min-w-[20px]">{num}.</span>
            {boldMatch ? (
              <span><strong style={{ color: 'var(--text-primary)' }}>{boldMatch[1]}</strong>{boldMatch[2]}</span>
            ) : content}
          </li>
        );
      } else if (trimmed === '') {
        elements.push(<div key={i} className="h-2" />);
      } else {
        // Handle inline code
        const parts = trimmed.split(/`([^`]+)`/);
        elements.push(
          <p key={i} className="mb-2 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            {parts.map((part, j) =>
              j % 2 === 1 ? (
                <code key={j} className="px-1.5 py-0.5 rounded text-sm font-mono text-go-cyan" style={{ backgroundColor: 'var(--bg-tertiary)' }}>
                  {part}
                </code>
              ) : part
            )}
          </p>
        );
      }
    });
    
    return elements;
  };

  return (
    <div className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6 text-sm animate-fade-in">
          <button onClick={() => navigate('lessons')} className="flex items-center gap-1 text-go-cyan hover:underline">
            <ArrowLeft size={16} />
            Lessons
          </button>
          <ChevronRight size={14} style={{ color: 'var(--text-tertiary)' }} />
          <span style={{ color: 'var(--text-secondary)' }}>{lesson.title}</span>
          {isCompleted && <CheckCircle2 size={16} className="text-go-success ml-1" />}
        </div>

        {/* Title */}
        <div className="mb-6 animate-fade-in">
          <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            {lesson.title}
          </h1>
          <p style={{ color: 'var(--text-secondary)' }}>{lesson.description}</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 p-1 rounded-xl w-fit animate-fade-in stagger-1" style={{ backgroundColor: 'var(--bg-tertiary)' }}>
          {[
            { id: 'content' as const, label: 'Lesson', icon: BookOpen },
            { id: 'code' as const, label: 'Code Editor', icon: Play },
            { id: 'quiz' as const, label: `Quiz (${lesson.quiz.length})`, icon: HelpCircle },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id 
                  ? 'bg-go-cyan text-white shadow-md' 
                  : ''
              }`}
              style={activeTab !== tab.id ? { color: 'var(--text-secondary)' } : {}}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Tab */}
        {activeTab === 'content' && (
          <div className="animate-fade-in">
            <div 
              className="p-8 rounded-2xl border mb-6"
              style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
            >
              {renderMarkdown(lesson.content)}
            </div>

            {/* Code Preview */}
            <div 
              className="rounded-2xl overflow-hidden border mb-6"
              style={{ borderColor: 'var(--border-color)' }}
            >
              <div className="flex items-center justify-between px-4 py-3" style={{ backgroundColor: '#1e1e2e' }}>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="ml-2 text-xs text-gray-400 font-mono">example.go</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyCode}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    {copied ? <Check size={14} /> : <Copy size={14} />}
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                  <button
                    onClick={() => setActiveTab('code')}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs bg-go-cyan text-white hover:bg-go-dark transition-colors"
                  >
                    <Play size={14} />
                    Open Editor
                  </button>
                </div>
              </div>
              <pre className="p-6 overflow-x-auto" style={{ backgroundColor: '#1e1e2e' }}>
                <code className="language-go text-sm">{lesson.codeExample}</code>
              </pre>
            </div>

            <div className="flex justify-center">
              <button
                onClick={() => setActiveTab('quiz')}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-go-cyan text-white font-medium hover:bg-go-dark transition-colors"
              >
                Take the Quiz
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* Code Editor Tab */}
        {activeTab === 'code' && (
          <div className="animate-fade-in">
            <div 
              className="rounded-2xl overflow-hidden border"
              style={{ borderColor: 'var(--border-color)' }}
            >
              {/* Editor Header */}
              <div className="flex items-center justify-between px-4 py-3" style={{ backgroundColor: '#1e1e2e' }}>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="ml-2 text-xs text-gray-400 font-mono">main.go</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCode(lesson.codeExample)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    <RotateCcw size={14} />
                    Reset
                  </button>
                  <button
                    onClick={copyCode}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    {copied ? <Check size={14} /> : <Copy size={14} />}
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                  <button
                    onClick={() => simulateRun()}
                    disabled={isRunning}
                    className="flex items-center gap-1 px-4 py-1.5 rounded-lg text-xs bg-go-success text-white hover:bg-go-success/80 transition-colors disabled:opacity-50"
                  >
                    <Play size={14} />
                    {isRunning ? 'Running...' : 'Run Code'}
                  </button>
                </div>
              </div>

              {/* Editor */}
              <div className="relative flex" style={{ backgroundColor: '#1e1e2e' }}>
                {/* Line Numbers */}
                <div
                  className="select-none text-right pr-3 pt-6 pb-6 pl-4 font-mono text-sm text-gray-600 flex-shrink-0 border-r border-white/5"
                  style={{ lineHeight: '1.6', fontFamily: "'JetBrains Mono', monospace", minWidth: '3rem' }}
                >
                  {code.split('\n').map((_, i) => {
                    const lineNum = i + 1;
                    const hasError = output && !output.success && output.errors.some(e => e.line === lineNum && e.severity === 'error');
                    return (
                      <div key={i} className={hasError ? 'text-red-400 font-bold' : ''}>{lineNum}</div>
                    );
                  })}
                </div>
                <textarea
                  ref={textareaRef}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full min-h-[400px] py-6 px-4 font-mono text-sm text-white bg-transparent resize-y focus:outline-none flex-1"
                  spellCheck={false}
                  style={{ 
                    tabSize: 4,
                    lineHeight: '1.6',
                    caretColor: '#00ADD8',
                    fontFamily: "'JetBrains Mono', monospace"
                  }}
                />
              </div>

              {/* Input Panel */}
              {showInputPanel && (
                <div className="border-t border-white/10 animate-fade-in" style={{ backgroundColor: '#0D1117' }}>
                  <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5">
                    <Terminal size={14} className="text-go-cyan" />
                    <span className="text-xs font-medium text-go-cyan">Program Input Required</span>
                    <span className="text-xs text-gray-500 ml-1">— provide values below, then run</span>
                  </div>
                  <div className="p-4 space-y-3">
                    {inputPrompts.map((prompt, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <label className="text-xs text-gray-400 font-mono min-w-[120px] text-right truncate" title={prompt}>
                          {prompt}:
                        </label>
                        <input
                          type="text"
                          value={userInputs[idx] || ''}
                          onChange={(e) => {
                            const next = [...userInputs];
                            next[idx] = e.target.value;
                            setUserInputs(next);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleRunWithInput();
                          }}
                          placeholder={`Enter ${prompt}...`}
                          className="flex-1 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-white font-mono placeholder-gray-600 focus:outline-none focus:border-go-cyan/50 focus:ring-1 focus:ring-go-cyan/30 transition-all"
                        />
                      </div>
                    ))}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={handleRunWithInput}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs bg-go-success text-white hover:bg-go-success/80 transition-colors font-medium"
                      >
                        <Play size={14} />
                        Run with Input
                      </button>
                      <button
                        onClick={() => setShowInputPanel(false)}
                        className="px-4 py-2 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Output */}
              {(output || isRunning) && (
                <div className="border-t border-white/10" style={{ backgroundColor: '#0D1117' }}>
                  <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5">
                    {output && !isRunning && (
                      <span className={`w-2 h-2 rounded-full ${output.success ? 'bg-green-400' : 'bg-red-400'}`} />
                    )}
                    <span className="text-xs font-medium text-gray-400">
                      {isRunning ? 'Output' : output?.success ? 'Output' : 'Compilation Error'}
                    </span>
                    {isRunning && (
                      <div className="w-4 h-4 border-2 border-go-cyan border-t-transparent rounded-full animate-spin" />
                    )}
                    {output && !isRunning && (
                      <span className={`ml-auto text-xs ${output.success ? 'text-green-400' : 'text-red-400'}`}>
                        {output.success ? '✓ exit code 0' : `✗ ${output.errors.filter(e => e.severity === 'error').length} error(s)`}
                      </span>
                    )}
                  </div>
                  <pre className={`p-4 text-sm font-mono whitespace-pre-wrap min-h-[60px] ${
                    isRunning ? 'text-gray-400' : output?.success ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {isRunning ? 'Compiling and running...' : output?.output || ''}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Quiz Tab */}
        {activeTab === 'quiz' && (
          <div className="animate-fade-in max-w-3xl">
            {lesson.quiz.length === 0 ? (
              <div className="text-center py-16">
                <p style={{ color: 'var(--text-secondary)' }}>No quiz for this lesson yet.</p>
              </div>
            ) : (
              <>
                {/* Quiz Score */}
                {quizSubmitted && quizScore !== null && (
                  <div 
                    className={`p-6 rounded-2xl border mb-6 ${
                      quizScore >= 70 ? 'border-go-success/30' : 'border-go-error/30'
                    }`}
                    style={{ backgroundColor: 'var(--bg-card)' }}
                  >
                    <div className="flex items-center gap-4">
                      {quizScore >= 70 ? (
                        <Award size={48} className="text-go-success" />
                      ) : (
                        <XCircle size={48} className="text-go-error" />
                      )}
                      <div>
                        <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                          {quizScore >= 70 ? '🎉 Great job!' : 'Keep practicing!'}
                        </h3>
                        <p style={{ color: 'var(--text-secondary)' }}>
                          You scored <strong className={quizScore >= 70 ? 'text-go-success' : 'text-go-error'}>{quizScore}%</strong>
                          {quizScore >= 70 ? ' — Lesson marked as complete!' : ' — You need 70% to pass.'}
                        </p>
                      </div>
                      <button
                        onClick={resetQuiz}
                        className="ml-auto flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-medium hover:bg-go-cyan/5 transition-colors"
                        style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                      >
                        <RotateCcw size={16} />
                        Retry
                      </button>
                    </div>
                  </div>
                )}

                {/* Questions */}
                <div className="space-y-6">
                  {lesson.quiz.map((q, qi) => (
                    <div
                      key={q.id}
                      className="p-6 rounded-2xl border"
                      style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
                    >
                      <h3 className="font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
                        <span className="text-go-cyan mr-2">Q{qi + 1}.</span>
                        {q.question}
                      </h3>
                      
                      <div className="space-y-2">
                        {q.options.map((option, oi) => {
                          const isSelected = quizAnswers[q.id] === oi;
                          const isCorrect = quizSubmitted && oi === q.correctAnswer;
                          const isWrong = quizSubmitted && isSelected && oi !== q.correctAnswer;

                          return (
                            <button
                              key={oi}
                              onClick={() => {
                                if (!quizSubmitted) {
                                  setQuizAnswers(prev => ({ ...prev, [q.id]: oi }));
                                }
                              }}
                              disabled={quizSubmitted}
                              className={`w-full text-left p-4 rounded-xl border text-sm transition-all flex items-center gap-3 ${
                                isCorrect ? 'border-go-success bg-go-success/10' :
                                isWrong ? 'border-go-error bg-go-error/10' :
                                isSelected ? 'border-go-cyan bg-go-cyan/10' : ''
                              }`}
                              style={!isCorrect && !isWrong && !isSelected ? {
                                borderColor: 'var(--border-color)',
                                color: 'var(--text-primary)'
                              } : { color: 'var(--text-primary)' }}
                            >
                              <span className={`w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                                isCorrect ? 'border-go-success text-go-success' :
                                isWrong ? 'border-go-error text-go-error' :
                                isSelected ? 'border-go-cyan bg-go-cyan text-white' : ''
                              }`} style={!isCorrect && !isWrong && !isSelected ? { borderColor: 'var(--border-color)', color: 'var(--text-secondary)' } : {}}>
                                {isCorrect ? <CheckCircle2 size={16} /> :
                                 isWrong ? <XCircle size={16} /> :
                                 String.fromCharCode(65 + oi)}
                              </span>
                              {option}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="mt-4 p-3 rounded-lg text-sm" style={{ backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                          💡 {q.explanation}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {!quizSubmitted && (
                  <div className="mt-8 flex justify-center">
                    <button
                      onClick={handleQuizSubmit}
                      disabled={Object.keys(quizAnswers).length < lesson.quiz.length}
                      className="px-8 py-3 rounded-xl bg-go-cyan text-white font-medium hover:bg-go-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Submit Answers ({Object.keys(quizAnswers).length}/{lesson.quiz.length})
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between mt-12 pt-8 border-t" style={{ borderColor: 'var(--border-color)' }}>
          {prevLesson ? (
            <button
              onClick={() => navigate('lesson', { lessonId: prevLesson.id })}
              className="flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium hover:bg-go-cyan/5 transition-colors"
              style={{ borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
            >
              <ChevronLeft size={18} />
              {prevLesson.title}
            </button>
          ) : <div />}
          {nextLesson ? (
            <button
              onClick={() => navigate('lesson', { lessonId: nextLesson.id })}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-go-cyan text-white text-sm font-medium hover:bg-go-dark transition-colors"
            >
              {nextLesson.title}
              <ChevronRight size={18} />
            </button>
          ) : (
            <button
              onClick={() => navigate('lessons')}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-go-cyan text-white text-sm font-medium hover:bg-go-dark transition-colors"
            >
              Back to Dashboard
              <ChevronRight size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
