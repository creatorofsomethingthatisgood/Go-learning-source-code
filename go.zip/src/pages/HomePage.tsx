import { useApp } from '../store/AppContext';
import { 
  ArrowRight, Zap, Shield, Globe, Cpu, 
  BookOpen, Code2, FolderKanban, Award,
  CheckCircle2, Users, Star
} from 'lucide-react';
import { lessons, challenges, projects } from '../data/lessons';

export default function HomePage() {
  const { navigate, isAuthenticated, progress } = useApp();

  const features = [
    { icon: Zap, title: 'Lightning Fast', desc: 'Go compiles to machine code, delivering blazing fast performance.', color: '#F59E0B' },
    { icon: Shield, title: 'Type Safe', desc: 'Static typing catches errors at compile time, not runtime.', color: '#10B981' },
    { icon: Globe, title: 'Built for Web', desc: 'Powerful standard library for building web servers and APIs.', color: '#3B82F6' },
    { icon: Cpu, title: 'Concurrency', desc: 'Goroutines make concurrent programming simple and efficient.', color: '#8B5CF6' },
  ];

  const stats = [
    { value: `${lessons.length}`, label: 'Lessons', icon: BookOpen },
    { value: `${challenges.length}`, label: 'Challenges', icon: Code2 },
    { value: `${projects.length}`, label: 'Projects', icon: FolderKanban },
    { value: '100%', label: 'Free', icon: Award },
  ];

  const testimonials = [
    { name: 'Sarah Chen', role: 'Backend Developer', text: 'GoMaster Academy helped me transition from Python to Go in just 3 weeks. The interactive examples are amazing!', rating: 5 },
    { name: 'Marcus Johnson', role: 'DevOps Engineer', text: 'The concurrency lessons are the best I\'ve found anywhere. Finally understand goroutines and channels.', rating: 5 },
    { name: 'Aisha Patel', role: 'Student', text: 'Clear explanations, great code examples, and the practice challenges really solidify the concepts.', rating: 5 },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-24 pb-20 sm:pt-32 sm:pb-28">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-go-cyan/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-go-dark/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-go-cyan/5 rounded-full blur-3xl" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6" 
                   style={{ backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                <span className="w-2 h-2 rounded-full bg-go-success animate-pulse" />
                Free & Open Learning Platform
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight mb-6">
                Master{' '}
                <span className="gradient-text">Go Programming</span>
                {' '}from Zero to Hero
              </h1>
              
              <p className="text-lg sm:text-xl mb-8 max-w-xl leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Interactive lessons, real-world projects, and coding challenges. 
                Learn Go the right way with hands-on practice and instant feedback.
              </p>

              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => navigate('lessons')}
                  className="group flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-go-cyan to-go-dark text-white font-semibold text-lg hover:shadow-xl hover:shadow-go-cyan/25 transition-all hover:-translate-y-0.5"
                >
                  Start Learning
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button
                  onClick={() => navigate('practice')}
                  className="flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-lg border-2 border-go-cyan/30 hover:border-go-cyan hover:bg-go-cyan/5 transition-all"
                  style={{ color: 'var(--text-primary)' }}
                >
                  <Code2 size={20} />
                  Try Challenges
                </button>
              </div>

              {/* Quick Stats */}
              {isAuthenticated && (
                <div className="mt-8 flex items-center gap-6 p-4 rounded-xl" style={{ backgroundColor: 'var(--bg-secondary)' }}>
                  <div>
                    <p className="text-2xl font-bold text-go-cyan">{progress.totalXP}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Total XP</p>
                  </div>
                  <div className="w-px h-10" style={{ backgroundColor: 'var(--border-color)' }} />
                  <div>
                    <p className="text-2xl font-bold text-go-success">{progress.completedLessons.length}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Completed</p>
                  </div>
                  <div className="w-px h-10" style={{ backgroundColor: 'var(--border-color)' }} />
                  <div>
                    <p className="text-2xl font-bold text-go-warning">{progress.currentStreak}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Streak</p>
                  </div>
                </div>
              )}
            </div>

            {/* Hero Code Block */}
            <div className="hidden lg:block animate-fade-in stagger-2">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-go-cyan/20 to-go-dark/20 rounded-2xl blur-xl" />
                <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ backgroundColor: '#1e1e2e' }}>
                  <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="ml-2 text-xs text-gray-400 font-mono">main.go</span>
                  </div>
                  <pre className="p-6 text-sm font-mono leading-relaxed overflow-x-auto">
                    <code>
                      <span className="text-purple-400">package</span> <span className="text-white">main</span>{'\n\n'}
                      <span className="text-purple-400">import</span> <span className="text-green-400">"fmt"</span>{'\n\n'}
                      <span className="text-purple-400">func</span> <span className="text-cyan-300">main</span><span className="text-white">() {'{'}</span>{'\n'}
                      {'    '}<span className="text-white">languages := []</span><span className="text-purple-400">string</span><span className="text-white">{'{'}</span>{'\n'}
                      {'        '}<span className="text-green-400">"Go"</span><span className="text-white">,</span>{'\n'}
                      {'        '}<span className="text-green-400">"is"</span><span className="text-white">,</span>{'\n'}
                      {'        '}<span className="text-green-400">"awesome!"</span><span className="text-white">,</span>{'\n'}
                      {'    '}<span className="text-white">{'}'}</span>{'\n\n'}
                      {'    '}<span className="text-purple-400">for</span><span className="text-white"> _, word := </span><span className="text-purple-400">range</span><span className="text-white"> languages {'{'}</span>{'\n'}
                      {'        '}<span className="text-white">fmt.</span><span className="text-cyan-300">Println</span><span className="text-white">(word)</span>{'\n'}
                      {'    '}<span className="text-white">{'}'}</span>{'\n'}
                      <span className="text-white">{'}'}</span>
                    </code>
                  </pre>
                  <div className="px-6 py-3 border-t border-white/10 bg-black/20">
                    <div className="flex items-center gap-2">
                      <span className="text-green-400 text-xs">▶</span>
                      <span className="text-gray-400 text-xs font-mono">Output: Go is awesome!</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-8 border-y" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <stat.icon className="mx-auto mb-2 text-go-cyan" size={24} />
                <p className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stat.value}</p>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Go */}
      <section className="py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Why Learn <span className="gradient-text">Go?</span>
            </h2>
            <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
              Go is designed for building fast, reliable, and efficient software at scale.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div
                key={i}
                className="group p-6 rounded-2xl border transition-all hover:shadow-lg hover:-translate-y-1 cursor-default"
                style={{ 
                  backgroundColor: 'var(--bg-card)', 
                  borderColor: 'var(--border-color)',
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                  style={{ backgroundColor: `${feature.color}15`, color: feature.color }}
                >
                  <feature.icon size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                  {feature.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Path */}
      <section className="py-20" style={{ backgroundColor: 'var(--bg-secondary)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Your Learning <span className="gradient-text">Path</span>
            </h2>
            <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
              A structured curriculum from basics to advanced topics
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { level: 'Beginner', color: '#10B981', topics: ['Hello World', 'Variables & Types', 'Control Flow', 'User Input', 'Slices & Maps'], icon: '🌱' },
              { level: 'Intermediate', color: '#F59E0B', topics: ['Functions', 'Structs & Interfaces', 'Error Handling', 'HTTP Servers', 'Testing'], icon: '🌿' },
              { level: 'Advanced', color: '#EF4444', topics: ['Goroutines', 'Channels', 'REST APIs', 'Microservices', 'Real-World Projects'], icon: '🌳' },
            ].map((path, i) => (
              <div
                key={i}
                className="p-8 rounded-2xl border transition-all hover:shadow-lg"
                style={{ 
                  backgroundColor: 'var(--bg-card)', 
                  borderColor: 'var(--border-color)' 
                }}
              >
                <div className="text-4xl mb-4">{path.icon}</div>
                <h3 className="text-xl font-bold mb-1" style={{ color: path.color }}>
                  {path.level}
                </h3>
                <ul className="space-y-2 mt-4">
                  {path.topics.map((topic, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                      <CheckCircle2 size={16} style={{ color: path.color }} />
                      {topic}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              What Learners <span className="gradient-text">Say</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl border"
                style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} size={16} className="fill-go-warning text-go-warning" />
                  ))}
                </div>
                <p className="text-sm mb-4 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white font-bold text-sm">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{t.name}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ backgroundColor: 'var(--bg-secondary)' }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-6xl mb-6">🐹</div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Ready to Start Your Go Journey?
          </h2>
          <p className="text-lg mb-8 max-w-xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
            Join thousands of developers learning Go. It's free, interactive, and fun.
          </p>
          <button
            onClick={() => navigate(isAuthenticated ? 'lessons' : 'auth')}
            className="group inline-flex items-center gap-2 px-10 py-4 rounded-xl bg-gradient-to-r from-go-cyan to-go-dark text-white font-semibold text-lg hover:shadow-xl hover:shadow-go-cyan/25 transition-all hover:-translate-y-0.5"
          >
            {isAuthenticated ? 'Continue Learning' : 'Get Started Free'}
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t" style={{ borderColor: 'var(--border-color)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white font-bold text-sm">
                Go
              </div>
              <span className="font-bold" style={{ color: 'var(--text-primary)' }}>
                GoMaster<span className="text-go-cyan">.academy</span>
              </span>
            </div>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              © 2024 GoMaster Academy. Learn Go, build amazing things.
            </p>
            <div className="flex items-center gap-4">
              <Users size={16} style={{ color: 'var(--text-secondary)' }} />
              <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Made with ❤️ for the Go community
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
