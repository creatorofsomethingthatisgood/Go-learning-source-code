import { useState, useEffect } from 'react';
import { useApp } from '../store/AppContext';
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, AlertCircle, Database } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

export default function AuthPage() {
  const { login, signup, navigate, isAuthenticated, authError } = useApp();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Sync authError from context
  useEffect(() => {
    if (authError) setError(authError);
  }, [authError]);

  if (isAuthenticated) {
    navigate('home');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (mode === 'login') {
      const success = await login(email, password);
      if (success) {
        navigate('lessons');
      }
    } else {
      if (name.trim().length < 2) {
        setError('Name must be at least 2 characters.');
        setLoading(false);
        return;
      }
      if (!email.includes('@')) {
        setError('Please enter a valid email.');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        setLoading(false);
        return;
      }
      const success = await signup(name, email, password);
      if (success) {
        navigate('lessons');
      }
    }
    setLoading(false);
  };
  
  const supabaseReady = isSupabaseConfigured();

  return (
    <div className="min-h-screen pt-20 flex items-center justify-center px-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white font-bold text-2xl mx-auto mb-4 shadow-lg glow-pulse">
            Go
          </div>
          <h1 className="text-2xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
            {mode === 'login' ? 'Welcome Back!' : 'Join GoMaster'}
          </h1>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            {mode === 'login' ? 'Sign in to continue your learning journey' : 'Create an account to track your progress'}
          </p>
        </div>

        {/* Form */}
        <div
          className="p-8 rounded-2xl border shadow-xl"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
        >
          {/* Tab Switch */}
          <div className="flex mb-6 p-1 rounded-xl" style={{ backgroundColor: 'var(--bg-tertiary)' }}>
            <button
              onClick={() => { setMode('login'); setError(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                mode === 'login' ? 'bg-go-cyan text-white shadow-md' : ''
              }`}
              style={mode !== 'login' ? { color: 'var(--text-secondary)' } : {}}
            >
              Sign In
            </button>
            <button
              onClick={() => { setMode('signup'); setError(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                mode === 'signup' ? 'bg-go-cyan text-white shadow-md' : ''
              }`}
              style={mode !== 'signup' ? { color: 'var(--text-secondary)' } : {}}
            >
              Sign Up
            </button>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-go-error/10 text-go-error text-sm mb-4">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>
                  Full Name
                </label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 focus:border-go-cyan transition-all"
                    style={{
                      backgroundColor: 'var(--input-bg)',
                      borderColor: 'var(--border-color)',
                      color: 'var(--text-primary)'
                    }}
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>
                Email
              </label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 focus:border-go-cyan transition-all"
                  style={{
                    backgroundColor: 'var(--input-bg)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-primary)'
                  }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>
                Password
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-12 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 focus:border-go-cyan transition-all"
                  style={{
                    backgroundColor: 'var(--input-bg)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-primary)'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-tertiary)' }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-go-cyan to-go-dark text-white font-medium hover:shadow-lg hover:shadow-go-cyan/25 transition-all disabled:opacity-70"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
              {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
              <button
                onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}
                className="text-go-cyan hover:underline font-medium"
              >
                {mode === 'login' ? 'Sign Up' : 'Sign In'}
              </button>
            </p>
          </div>
        </div>

        <div className="text-center mt-6">
          {supabaseReady ? (
            <div className="flex items-center justify-center gap-2 text-xs text-go-success">
              <Database size={14} />
              <span>Connected to database — data syncs across devices</span>
            </div>
          ) : (
            <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
              Data is stored locally in your browser. Configure Supabase for cloud sync.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
