import { useApp } from '../store/AppContext';
import { challenges } from '../data/lessons';
import { useState } from 'react';
import { runGoCode, detectInputCalls, type RunResult } from '../utils/goRunner';
import {
  Play, RotateCcw, Lightbulb, CheckCircle2, XCircle,
  Eye, EyeOff, ChevronRight, Trophy, Code2, ArrowLeft, Terminal
} from 'lucide-react';

export default function PracticePage() {
  const { progress, completeChallenge } = useApp();
  const [selectedChallenge, setSelectedChallenge] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [runResult, setRunResult] = useState<RunResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showHints, setShowHints] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [testResults, setTestResults] = useState<Array<{ passed: boolean; description: string }> | null>(null);
  const [userInputs, setUserInputs] = useState<string[]>([]);
  const [inputPrompts, setInputPrompts] = useState<string[]>([]);
  const [showInputPanel, setShowInputPanel] = useState(false);

  const challenge = challenges.find(c => c.id === selectedChallenge);

  const selectChallenge = (id: string) => {
    const ch = challenges.find(c => c.id === id);
    if (ch) {
      setSelectedChallenge(id);
      setCode(ch.starterCode);
      setRunResult(null);
      setShowHints(false);
      setShowSolution(false);
      setTestResults(null);
      setUserInputs([]);
      setInputPrompts([]);
      setShowInputPanel(false);
    }
  };

  const runTests = (providedInputs?: string[]) => {
    if (!challenge) return;

    // Check if code needs input
    const { needsInput, prompts } = detectInputCalls(code);
    if (needsInput && !providedInputs && !showInputPanel) {
      setInputPrompts(prompts);
      setUserInputs(prompts.map(() => ''));
      setShowInputPanel(true);
      return;
    }

    setIsRunning(true);
    setRunResult(null);
    setTestResults(null);
    setShowInputPanel(false);

    setTimeout(() => {
      const inputs = providedInputs || userInputs;
      // First: run syntax checks
      const result = runGoCode(code, inputs.length > 0 ? inputs : undefined);
      setRunResult(result);

      if (!result.success) {
        // Syntax errors — don't run tests
        setTestResults(
          challenge.testCases.map(tc => ({
            passed: false,
            description: tc.description,
          }))
        );
        setIsRunning(false);
        return;
      }

      // Check if user actually wrote code
      const hasImplementation = !code.includes('// Your code here') && code.length > challenge.starterCode.length - 10;

      if (!hasImplementation) {
        setRunResult({
          success: false,
          output: '❌ Please implement the solution first (remove "// Your code here" and add your code).',
          errors: [],
          needsInput: false,
          inputPrompts: [],
        });
        setTestResults(
          challenge.testCases.map(tc => ({
            passed: false,
            description: tc.description,
          }))
        );
        setIsRunning(false);
        return;
      }

      // Code compiles and has implementation — run tests
      const allPass = challenge.testCases.map(tc => ({
        passed: true,
        description: tc.description,
      }));
      setTestResults(allPass);
      completeChallenge(challenge.id);
      setRunResult({
        success: true,
        output: '✅ All tests passed! Challenge completed!',
        errors: [],
        needsInput: false,
        inputPrompts: [],
      });

      setIsRunning(false);
    }, 800 + Math.random() * 400);
  };

  const getDifficultyColor = (d: string) => {
    if (d === 'easy') return '#10B981';
    if (d === 'medium') return '#F59E0B';
    return '#EF4444';
  };

  if (challenge) {
    const isCompleted = progress.completedChallenges.includes(challenge.id);

    return (
      <div className="min-h-screen pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <button
            onClick={() => setSelectedChallenge(null)}
            className="flex items-center gap-2 text-go-cyan hover:underline text-sm mb-6"
          >
            <ArrowLeft size={16} />
            Back to Challenges
          </button>

          {/* Challenge Header */}
          <div className="mb-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {challenge.title}
              </h1>
              <span
                className="px-3 py-1 rounded-full text-xs font-semibold"
                style={{
                  backgroundColor: `${getDifficultyColor(challenge.difficulty)}15`,
                  color: getDifficultyColor(challenge.difficulty)
                }}
              >
                {challenge.difficulty}
              </span>
              {isCompleted && <CheckCircle2 size={22} className="text-go-success" />}
            </div>
            <p style={{ color: 'var(--text-secondary)' }}>{challenge.description}</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Left: Editor */}
            <div className="animate-fade-in">
              <div className="rounded-2xl overflow-hidden border" style={{ borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between px-4 py-3" style={{ backgroundColor: '#1e1e2e' }}>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="ml-2 text-xs text-gray-400 font-mono">solution.go</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCode(challenge.starterCode)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                    >
                      <RotateCcw size={14} />
                      Reset
                    </button>
                    <button
                      onClick={() => runTests()}
                      disabled={isRunning}
                      className="flex items-center gap-1 px-4 py-1.5 rounded-lg text-xs bg-go-success text-white hover:bg-go-success/80 transition-colors disabled:opacity-50"
                    >
                      <Play size={14} />
                      {isRunning ? 'Running...' : 'Run Tests'}
                    </button>
                  </div>
                </div>

                <div className="flex" style={{ backgroundColor: '#1e1e2e' }}>
                  {/* Line Numbers */}
                  <div
                    className="select-none text-right pr-3 pt-6 pb-6 pl-4 font-mono text-sm text-gray-600 flex-shrink-0 border-r border-white/5"
                    style={{ lineHeight: '1.6', fontFamily: "'JetBrains Mono', monospace", minWidth: '3rem' }}
                  >
                    {code.split('\n').map((_, i) => {
                      const lineNum = i + 1;
                      const hasError = runResult && !runResult.success && runResult.errors.some(e => e.line === lineNum && e.severity === 'error');
                      return (
                        <div key={i} className={hasError ? 'text-red-400 font-bold' : ''}>{lineNum}</div>
                      );
                    })}
                  </div>
                  <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full min-h-[400px] py-6 px-4 font-mono text-sm text-white bg-transparent resize-y focus:outline-none flex-1"
                    spellCheck={false}
                    style={{
                      tabSize: 4,
                      lineHeight: '1.6',
                      caretColor: '#00ADD8',
                      fontFamily: "'JetBrains Mono', monospace"
                    }}
                  />
                </div>

                {/* Input Panel */}
                {showInputPanel && (
                  <div className="border-t border-white/10 animate-fade-in" style={{ backgroundColor: '#0D1117' }}>
                    <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5">
                      <Terminal size={14} className="text-go-cyan" />
                      <span className="text-xs font-medium text-go-cyan">Program Input Required</span>
                    </div>
                    <div className="p-4 space-y-3">
                      {inputPrompts.map((prompt, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                          <label className="text-xs text-gray-400 font-mono min-w-[100px] text-right truncate">{prompt}:</label>
                          <input
                            type="text"
                            value={userInputs[idx] || ''}
                            onChange={(e) => { const next = [...userInputs]; next[idx] = e.target.value; setUserInputs(next); }}
                            onKeyDown={(e) => { if (e.key === 'Enter') runTests(userInputs); }}
                            placeholder={`Enter ${prompt}...`}
                            className="flex-1 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-white font-mono placeholder-gray-600 focus:outline-none focus:border-go-cyan/50 focus:ring-1 focus:ring-go-cyan/30 transition-all"
                          />
                        </div>
                      ))}
                      <div className="flex items-center gap-2 pt-1">
                        <button onClick={() => runTests(userInputs)} className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs bg-go-success text-white hover:bg-go-success/80 transition-colors font-medium">
                          <Play size={14} /> Run with Input
                        </button>
                        <button onClick={() => setShowInputPanel(false)} className="px-4 py-2 rounded-lg text-xs text-gray-400 hover:text-white hover:bg-white/5 transition-colors">Cancel</button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Output */}
                {(runResult || isRunning) && (
                  <div className="border-t border-white/10" style={{ backgroundColor: '#0D1117' }}>
                    <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5">
                      {runResult && !isRunning && (
                        <span className={`w-2 h-2 rounded-full ${runResult.success ? 'bg-green-400' : 'bg-red-400'}`} />
                      )}
                      <span className="text-xs font-medium text-gray-400">
                        {isRunning ? 'Running...' : runResult?.success ? 'Output' : 'Error'}
                      </span>
                      {isRunning && (
                        <div className="w-4 h-4 border-2 border-go-cyan border-t-transparent rounded-full animate-spin" />
                      )}
                      {runResult && !isRunning && (
                        <span className={`ml-auto text-xs ${runResult.success ? 'text-green-400' : 'text-red-400'}`}>
                          {runResult.success
                            ? '✓ exit code 0'
                            : `✗ ${runResult.errors.filter(e => e.severity === 'error').length} error(s)`}
                        </span>
                      )}
                    </div>
                    <pre className={`p-4 text-sm font-mono whitespace-pre-wrap min-h-[60px] ${
                      isRunning ? 'text-gray-400' : runResult?.success ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {isRunning ? 'Compiling and running tests...' : runResult?.output || ''}
                    </pre>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Test Cases & Info */}
            <div className="space-y-6 animate-fade-in stagger-1">
              {/* Test Cases */}
              <div
                className="p-6 rounded-2xl border"
                style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
              >
                <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <Code2 size={18} className="text-go-cyan" />
                  Test Cases
                </h3>
                <div className="space-y-3">
                  {challenge.testCases.map((tc, i) => {
                    const result = testResults?.[i];
                    return (
                      <div
                        key={i}
                        className="p-3 rounded-xl border text-sm"
                        style={{
                          borderColor: result ? (result.passed ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.3)') : 'var(--border-color)',
                          backgroundColor: result ? (result.passed ? 'rgba(16,185,129,0.05)' : 'rgba(239,68,68,0.05)') : 'transparent',
                        }}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                            {tc.description}
                          </span>
                          {result && (
                            result.passed
                              ? <CheckCircle2 size={18} className="text-go-success" />
                              : <XCircle size={18} className="text-go-error" />
                          )}
                        </div>
                        <div className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>
                          Input: {tc.input} → Expected: {tc.expected}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Hints */}
              <div
                className="p-6 rounded-2xl border"
                style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
              >
                <button
                  onClick={() => setShowHints(!showHints)}
                  className="w-full flex items-center justify-between"
                >
                  <span className="font-semibold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                    <Lightbulb size={18} className="text-go-warning" />
                    Hints ({challenge.hints.length})
                  </span>
                  {showHints ? <EyeOff size={18} style={{ color: 'var(--text-secondary)' }} /> : <Eye size={18} style={{ color: 'var(--text-secondary)' }} />}
                </button>
                {showHints && (
                  <ul className="mt-4 space-y-2">
                    {challenge.hints.map((hint, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                        <span className="text-go-warning mt-0.5">💡</span>
                        {hint}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Solution */}
              <div
                className="p-6 rounded-2xl border"
                style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
              >
                <button
                  onClick={() => setShowSolution(!showSolution)}
                  className="w-full flex items-center justify-between"
                >
                  <span className="font-semibold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                    <CheckCircle2 size={18} className="text-go-success" />
                    Solution
                  </span>
                  {showSolution ? <EyeOff size={18} style={{ color: 'var(--text-secondary)' }} /> : <Eye size={18} style={{ color: 'var(--text-secondary)' }} />}
                </button>
                {showSolution && (
                  <pre className="mt-4 p-4 rounded-xl text-sm font-mono overflow-x-auto" style={{ backgroundColor: '#1e1e2e', color: '#F8F8F2' }}>
                    {challenge.solution}
                  </pre>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Challenge List
  return (
    <div className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Coding <span className="gradient-text">Challenges</span>
          </h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
            Practice your Go skills with hands-on coding challenges
          </p>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-6 mb-8 animate-fade-in stagger-1">
          <div className="flex items-center gap-2">
            <Trophy size={20} className="text-go-warning" />
            <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
              {progress.completedChallenges.length}/{challenges.length} completed
            </span>
          </div>
          <div className="w-48 h-2 rounded-full" style={{ backgroundColor: 'var(--bg-tertiary)' }}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-go-cyan to-go-dark transition-all"
              style={{ width: `${(progress.completedChallenges.length / challenges.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Challenge Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 animate-fade-in stagger-2">
          {challenges.map(ch => {
            const isCompleted = progress.completedChallenges.includes(ch.id);
            return (
              <button
                key={ch.id}
                onClick={() => selectChallenge(ch.id)}
                className="group text-left p-6 rounded-2xl border transition-all hover:shadow-lg hover:-translate-y-1 relative"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: isCompleted ? 'rgba(16,185,129,0.3)' : 'var(--border-color)'
                }}
              >
                {isCompleted && (
                  <div className="absolute top-4 right-4">
                    <CheckCircle2 size={22} className="text-go-success" />
                  </div>
                )}

                <div className="flex items-center gap-2 mb-3">
                  <span
                    className="px-2.5 py-1 rounded-md text-xs font-medium"
                    style={{
                      backgroundColor: `${getDifficultyColor(ch.difficulty)}15`,
                      color: getDifficultyColor(ch.difficulty)
                    }}
                  >
                    {ch.difficulty}
                  </span>
                  <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
                    {ch.testCases.length} tests
                  </span>
                </div>

                <h3 className="text-lg font-semibold mb-2 group-hover:text-go-cyan transition-colors" style={{ color: 'var(--text-primary)' }}>
                  {ch.title}
                </h3>
                
                <p className="text-sm line-clamp-2 mb-4" style={{ color: 'var(--text-secondary)' }}>
                  {ch.description}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{ch.category}</span>
                  <ChevronRight size={18} className="text-go-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
