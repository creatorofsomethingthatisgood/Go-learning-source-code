import { useApp } from '../store/AppContext';
import { lessons, categories } from '../data/lessons';
import { 
  Clock, CheckCircle2, ChevronRight, BookOpen, 
  Search, BarChart3
} from 'lucide-react';
import { useState, useMemo } from 'react';

export default function LessonsDashboard() {
  const { navigate, progress } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);

  const filteredLessons = useMemo(() => {
    return lessons.filter(lesson => {
      const matchesSearch = lesson.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lesson.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || lesson.category === selectedCategory;
      const matchesDifficulty = !selectedDifficulty || lesson.difficulty === selectedDifficulty;
      return matchesSearch && matchesCategory && matchesDifficulty;
    });
  }, [searchQuery, selectedCategory, selectedDifficulty]);

  const completedCount = progress.completedLessons.length;
  const totalLessons = lessons.length;
  const progressPercent = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;

  const getDifficultyColor = (d: string) => {
    if (d === 'beginner') return '#10B981';
    if (d === 'intermediate') return '#F59E0B';
    return '#EF4444';
  };

  const getCategoryInfo = (id: string) => categories.find(c => c.id === id);

  return (
    <div className="min-h-screen pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Lessons <span className="gradient-text">Dashboard</span>
          </h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
            Master Go step by step with structured lessons
          </p>
        </div>

        {/* Progress Overview */}
        <div 
          className="p-6 rounded-2xl border mb-8 animate-fade-in stagger-1"
          style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-3">
              <BarChart3 className="text-go-cyan" size={24} />
              <div>
                <h3 className="font-semibold" style={{ color: 'var(--text-primary)' }}>Your Progress</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  {completedCount} of {totalLessons} lessons completed
                </p>
              </div>
            </div>
            <div className="text-2xl font-bold text-go-cyan">{progressPercent}%</div>
          </div>
          <div className="w-full h-3 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--bg-tertiary)' }}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-go-cyan to-go-dark transition-all duration-1000"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8 animate-fade-in stagger-2">
          {/* Search */}
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} />
            <input
              type="text"
              placeholder="Search lessons..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 focus:border-go-cyan transition-all"
              style={{ 
                backgroundColor: 'var(--input-bg)', 
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory || ''}
            onChange={(e) => setSelectedCategory(e.target.value || null)}
            className="px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 cursor-pointer"
            style={{ 
              backgroundColor: 'var(--input-bg)', 
              borderColor: 'var(--border-color)',
              color: 'var(--text-primary)'
            }}
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
            ))}
          </select>

          {/* Difficulty Filter */}
          <select
            value={selectedDifficulty || ''}
            onChange={(e) => setSelectedDifficulty(e.target.value || null)}
            className="px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-go-cyan/50 cursor-pointer"
            style={{ 
              backgroundColor: 'var(--input-bg)', 
              borderColor: 'var(--border-color)',
              color: 'var(--text-primary)'
            }}
          >
            <option value="">All Levels</option>
            <option value="beginner">🌱 Beginner</option>
            <option value="intermediate">🌿 Intermediate</option>
            <option value="advanced">🌳 Advanced</option>
          </select>
        </div>

        {/* Category Quick Filter */}
        <div className="flex flex-wrap gap-2 mb-8 animate-fade-in stagger-3">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              !selectedCategory ? 'bg-go-cyan text-white' : ''
            }`}
            style={!selectedCategory ? {} : { 
              backgroundColor: 'var(--bg-tertiary)', 
              color: 'var(--text-secondary)' 
            }}
          >
            All
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedCategory === cat.id ? 'text-white' : ''
              }`}
              style={selectedCategory === cat.id 
                ? { backgroundColor: cat.color }
                : { backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }
              }
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>

        {/* Lessons Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredLessons.map((lesson) => {
            const isCompleted = progress.completedLessons.includes(lesson.id);
            const catInfo = getCategoryInfo(lesson.category);
            const quizScore = progress.quizScores[lesson.id];

            return (
              <button
                key={lesson.id}
                onClick={() => navigate('lesson', { lessonId: lesson.id })}
                className="group text-left p-6 rounded-2xl border transition-all hover:shadow-lg hover:-translate-y-1 relative overflow-hidden"
                style={{ 
                  backgroundColor: 'var(--bg-card)', 
                  borderColor: isCompleted ? 'rgba(16,185,129,0.3)' : 'var(--border-color)' 
                }}
              >
                {isCompleted && (
                  <div className="absolute top-4 right-4">
                    <CheckCircle2 size={22} className="text-go-success" />
                  </div>
                )}

                <div className="flex items-center gap-2 mb-3">
                  <span 
                    className="px-2.5 py-1 rounded-md text-xs font-medium"
                    style={{ 
                      backgroundColor: `${catInfo?.color}15`,
                      color: catInfo?.color 
                    }}
                  >
                    {catInfo?.icon} {catInfo?.name}
                  </span>
                  <span
                    className="px-2.5 py-1 rounded-md text-xs font-medium"
                    style={{ 
                      backgroundColor: `${getDifficultyColor(lesson.difficulty)}15`,
                      color: getDifficultyColor(lesson.difficulty)
                    }}
                  >
                    {lesson.difficulty}
                  </span>
                </div>

                <h3 className="text-lg font-semibold mb-2 group-hover:text-go-cyan transition-colors" style={{ color: 'var(--text-primary)' }}>
                  {lesson.title}
                </h3>
                
                <p className="text-sm mb-4 line-clamp-2" style={{ color: 'var(--text-secondary)' }}>
                  {lesson.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-xs" style={{ color: 'var(--text-tertiary)' }}>
                    <span className="flex items-center gap-1">
                      <Clock size={14} />
                      {lesson.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <BookOpen size={14} />
                      {lesson.quiz.length} quiz
                    </span>
                  </div>
                  {quizScore !== undefined && (
                    <span className="text-xs font-medium text-go-warning">
                      Quiz: {quizScore}%
                    </span>
                  )}
                  <ChevronRight size={18} className="text-go-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            );
          })}
        </div>

        {filteredLessons.length === 0 && (
          <div className="text-center py-16">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>No lessons found</h3>
            <p style={{ color: 'var(--text-secondary)' }}>Try adjusting your filters or search query.</p>
          </div>
        )}
      </div>
    </div>
  );
}
