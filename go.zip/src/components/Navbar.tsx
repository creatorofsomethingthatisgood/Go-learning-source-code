import { useApp } from '../store/AppContext';
import { 
  Sun, Moon, Menu, X, BookOpen, Code2, FolderKanban, 
  LogIn, LogOut, User, Trophy, Zap
} from 'lucide-react';

export default function Navbar() {
  const { 
    page, navigate, darkMode, toggleDarkMode, 
    sidebarOpen, toggleSidebar, user, isAuthenticated, logout, progress 
  } = useApp();

  const navItems = [
    { id: 'home' as const, label: 'Home', icon: BookOpen },
    { id: 'lessons' as const, label: 'Lessons', icon: BookOpen },
    { id: 'practice' as const, label: 'Practice', icon: Code2 },
    { id: 'projects' as const, label: 'Projects', icon: FolderKanban },
  ];

  return (
    <nav 
      className="fixed top-0 left-0 right-0 z-50 border-b backdrop-blur-xl"
      style={{ 
        backgroundColor: 'var(--nav-bg)', 
        borderColor: 'var(--border-color)' 
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={() => navigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white font-bold text-lg shadow-lg group-hover:shadow-go-cyan/30 transition-shadow">
              Go
            </div>
            <span className="text-lg font-bold hidden sm:block" style={{ color: 'var(--text-primary)' }}>
              GoMaster<span className="text-go-cyan">.academy</span>
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                  page === item.id 
                    ? 'bg-go-cyan/10 text-go-cyan' 
                    : 'hover:bg-go-cyan/5'
                }`}
                style={{ color: page === item.id ? undefined : 'var(--text-secondary)' }}
              >
                <item.icon size={16} />
                {item.label}
              </button>
            ))}
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-2">
            {/* XP Badge */}
            {isAuthenticated && (
              <div 
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-primary)' }}
              >
                <Zap size={14} className="text-go-warning" />
                {progress.totalXP} XP
              </div>
            )}
            
            {/* Streak */}
            {isAuthenticated && progress.currentStreak > 0 && (
              <div 
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                style={{ backgroundColor: 'var(--bg-tertiary)', color: 'var(--text-primary)' }}
              >
                <Trophy size={14} className="text-go-warning" />
                {progress.currentStreak}
              </div>
            )}

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg transition-colors hover:bg-go-cyan/10"
              style={{ color: 'var(--text-secondary)' }}
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* Auth Button */}
            {isAuthenticated ? (
              <div className="hidden sm:flex items-center gap-2">
                <div 
                  className="w-8 h-8 rounded-full bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white text-sm font-bold"
                >
                  {user?.avatar}
                </div>
                <button
                  onClick={logout}
                  className="p-2 rounded-lg transition-colors hover:bg-red-500/10 text-red-400"
                  title="Logout"
                >
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigate('auth')}
                className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg bg-go-cyan text-white text-sm font-medium hover:bg-go-dark transition-colors"
              >
                <LogIn size={16} />
                Sign In
              </button>
            )}

            {/* Mobile Menu */}
            <button
              onClick={toggleSidebar}
              className="md:hidden p-2 rounded-lg transition-colors"
              style={{ color: 'var(--text-secondary)' }}
            >
              {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {sidebarOpen && (
        <div 
          className="md:hidden border-t animate-fade-in"
          style={{ 
            backgroundColor: 'var(--bg-primary)', 
            borderColor: 'var(--border-color)' 
          }}
        >
          <div className="px-4 py-3 space-y-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  page === item.id 
                    ? 'bg-go-cyan/10 text-go-cyan' 
                    : ''
                }`}
                style={{ color: page === item.id ? undefined : 'var(--text-primary)' }}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
            <div className="pt-2 border-t" style={{ borderColor: 'var(--border-color)' }}>
              {isAuthenticated ? (
                <div className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-go-cyan to-go-dark flex items-center justify-center text-white text-sm font-bold">
                      {user?.avatar}
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{user?.name}</p>
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{progress.totalXP} XP</p>
                    </div>
                  </div>
                  <button onClick={logout} className="text-red-400 hover:text-red-300">
                    <LogOut size={18} />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => navigate('auth')}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-go-cyan"
                >
                  <User size={18} />
                  Sign In / Sign Up
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
