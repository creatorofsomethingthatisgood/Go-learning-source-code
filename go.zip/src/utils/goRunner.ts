/**
 * Go Code Simulator
 *
 * A client-side Go code analyzer and output simulator.
 * Performs syntax checks, detects common errors, and simulates output
 * for fmt.Println, fmt.Printf, fmt.Print calls.
 */

export interface RunResult {
  success: boolean;
  output: string;
  errors: GoError[];
  needsInput: boolean;
  inputPrompts: string[];
}

export interface GoError {
  line: number;
  column: number;
  message: string;
  severity: 'error' | 'warning';
}

// ─── Helpers ────────────────────────────────────────────────────────────────

/** Strip all comments from Go source, preserving line structure. */
function stripComments(code: string): string {
  const lines = code.split('\n');
  const result: string[] = [];
  let inBlock = false;

  for (const line of lines) {
    let out = '';
    let i = 0;
    let inStr = false;
    let inRaw = false;
    let inRune = false;

    while (i < line.length) {
      const ch = line[i];
      const next = line[i + 1] || '';

      if (inBlock) {
        if (ch === '*' && next === '/') { inBlock = false; i += 2; continue; }
        i++; continue;
      }
      if (inRaw) {
        out += ch;
        if (ch === '`') inRaw = false;
        i++; continue;
      }
      if (inRune) {
        out += ch;
        if (ch === '\\') { out += next; i += 2; continue; }
        if (ch === "'") inRune = false;
        i++; continue;
      }
      if (inStr) {
        out += ch;
        if (ch === '\\') { out += next; i += 2; continue; }
        if (ch === '"') inStr = false;
        i++; continue;
      }

      // Not in any literal
      if (ch === '/' && next === '/') break;           // line comment
      if (ch === '/' && next === '*') { inBlock = true; i += 2; continue; }
      if (ch === '"')  { inStr = true;  out += ch; i++; continue; }
      if (ch === '`')  { inRaw = true;  out += ch; i++; continue; }
      if (ch === "'")  { inRune = true; out += ch; i++; continue; }

      out += ch;
      i++;
    }
    result.push(out);
  }
  return result.join('\n');
}

// ─── Syntax & Structure Checks ─────────────────────────────────────────────

function checkBraces(code: string): GoError[] {
  const errors: GoError[] = [];
  const stack: { char: string; line: number; col: number }[] = [];
  const lines = code.split('\n');

  let inString = false;
  let inRawString = false;
  let inRune = false;
  let inLineComment = false;
  let inBlockComment = false;

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const line = lines[lineIdx];
    inLineComment = false;

    for (let col = 0; col < line.length; col++) {
      const ch = line[col];
      const next = line[col + 1] || '';

      // Block comment
      if (inBlockComment) {
        if (ch === '*' && next === '/') { inBlockComment = false; col++; }
        continue;
      }
      if (inLineComment) continue;

      // Raw string (backtick)
      if (inRawString) {
        if (ch === '`') inRawString = false;
        continue;
      }

      // Regular double-quoted string
      if (inString) {
        if (ch === '\\') { col++; continue; }
        if (ch === '"') inString = false;
        continue;
      }

      // Rune literal (single-quoted)
      if (inRune) {
        if (ch === '\\') { col++; continue; }
        if (ch === "'") inRune = false;
        continue;
      }

      // Detect starts
      if (ch === '/' && next === '/') { inLineComment = true; continue; }
      if (ch === '/' && next === '*') { inBlockComment = true; col++; continue; }
      if (ch === '"')  { inString = true; continue; }
      if (ch === '`')  { inRawString = true; continue; }
      if (ch === "'")  { inRune = true; continue; }

      // Track braces / parens / brackets
      if (ch === '{' || ch === '(' || ch === '[') {
        stack.push({ char: ch, line: lineIdx + 1, col: col + 1 });
      } else if (ch === '}' || ch === ')' || ch === ']') {
        const expected = ch === '}' ? '{' : ch === ')' ? '(' : '[';
        if (stack.length === 0) {
          errors.push({ line: lineIdx + 1, column: col + 1, message: `unexpected '${ch}', no matching '${expected}'`, severity: 'error' });
        } else {
          const top = stack.pop()!;
          if (top.char !== expected) {
            errors.push({ line: lineIdx + 1, column: col + 1, message: `unexpected '${ch}', expected closing for '${top.char}' opened at line ${top.line}`, severity: 'error' });
          }
        }
      }
    }
  }

  if (inString) {
    errors.push({ line: lines.length, column: 1, message: 'unterminated string literal', severity: 'error' });
  }
  if (inRawString) {
    errors.push({ line: lines.length, column: 1, message: 'unterminated raw string literal', severity: 'error' });
  }
  if (inBlockComment) {
    errors.push({ line: lines.length, column: 1, message: 'unterminated block comment', severity: 'error' });
  }
  for (const u of stack) {
    errors.push({ line: u.line, column: u.col, message: `unclosed '${u.char}'`, severity: 'error' });
  }
  return errors;
}

function checkPackageDeclaration(code: string): GoError[] {
  const stripped = stripComments(code).trim();
  if (!stripped.startsWith('package ')) {
    return [{ line: 1, column: 1, message: "expected 'package' declaration at start of file", severity: 'error' }];
  }
  return [];
}

function checkMainFunction(code: string): GoError[] {
  const pkg = code.match(/^package\s+(\w+)/m);
  if (pkg && pkg[1] === 'main') {
    if (!/func\s+main\s*\(\s*\)/.test(code)) {
      return [{ line: code.split('\n').length, column: 1, message: "function 'main' is not defined in package 'main'", severity: 'error' }];
    }
  }
  return [];
}

function checkFuncDeclarationBraces(code: string): GoError[] {
  const errors: GoError[] = [];
  const lines = code.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith('//') || line.startsWith('/*')) continue;

    // Detect func declaration that does NOT contain a '{'
    // Pattern: func [optional receiver] name(params) [optional return] <end-of-line>
    const funcDeclNoBody = /^func\s+(?:\([^)]*\)\s*)?\w+\s*\([^)]*\)\s*(?:\([^)]*\)|[\w\s*[\]]*)?$/;
    if (funcDeclNoBody.test(line) && !line.includes('{')) {
      // Check whether next non-empty line starts with '{'
      let nextLine = '';
      for (let j = i + 1; j < lines.length; j++) {
        if (lines[j].trim()) { nextLine = lines[j].trim(); break; }
      }
      if (!nextLine.startsWith('{')) {
        errors.push({
          line: i + 1,
          column: line.length + 1,
          message: "missing '{' after function declaration (Go requires opening brace on the same line)",
          severity: 'error',
        });
      }
    }
  }
  return errors;
}

function checkCommonMistakes(code: string): GoError[] {
  const errors: GoError[] = [];
  const lines = code.split('\n');

  const validFmtFuncs = new Set([
    'Println', 'Printf', 'Print', 'Sprintf', 'Fprintf', 'Sscanf',
    'Scanf', 'Scanln', 'Scan', 'Errorf', 'Sscan', 'Sscanln',
    'Fprint', 'Fprintln', 'Sprint', 'Sprintln',
  ]);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('/*')) continue;

    // ── Check for misspelled fmt function names ────────────────────────
    const fmtCallRe = /fmt\.(\w+)\s*\(/g;
    let m: RegExpExecArray | null;
    while ((m = fmtCallRe.exec(trimmed)) !== null) {
      const funcName = m[1];
      if (!validFmtFuncs.has(funcName)) {
        const lower = funcName.toLowerCase();
        let suggestion = '';
        if (lower === 'println') suggestion = 'Println';
        else if (lower === 'printf') suggestion = 'Printf';
        else if (lower === 'print') suggestion = 'Print';
        else if (lower === 'sprintf') suggestion = 'Sprintf';
        else if (lower === 'errorf') suggestion = 'Errorf';
        else if (lower.includes('print')) suggestion = 'Println';
        else {
          for (const vf of validFmtFuncs) {
            if (vf.toLowerCase().startsWith(lower.slice(0, 3))) { suggestion = vf; break; }
          }
        }
        const col = line.indexOf(`fmt.${funcName}`) + 5;
        errors.push({
          line: i + 1, column: col,
          message: `fmt.${funcName} is not defined${suggestion ? ` (did you mean fmt.${suggestion}?)` : ''}`,
          severity: 'error',
        });
      }
    }

    // ── Check for unterminated string literal on a single line ─────────
    // Walk through the line tracking quote state properly,
    // handling escape sequences and skipping rune literals.
    {
      let inStr = false;
      let inRuneLit = false;
      let inRaw = false;
      for (let c = 0; c < trimmed.length; c++) {
        const ch = trimmed[c];
        const nx = trimmed[c + 1] || '';

        // Line comment — rest of line is not code
        if (!inStr && !inRuneLit && !inRaw && ch === '/' && nx === '/') break;

        if (inRaw) { if (ch === '`') inRaw = false; continue; }

        if (inRuneLit) {
          if (ch === '\\') { c++; continue; }
          if (ch === "'") inRuneLit = false;
          continue;
        }

        if (inStr) {
          if (ch === '\\') { c++; continue; }
          if (ch === '"') inStr = false;
          continue;
        }

        // Not inside any literal
        if (ch === '`')  { inRaw = true; continue; }
        if (ch === "'")  { inRuneLit = true; continue; }
        if (ch === '"')  { inStr = true; continue; }
      }
      // If we're still inside a double-quoted string at end-of-line,
      // check whether the next non-blank line is a continuation
      // (Go doesn't allow multi-line double-quoted strings, but the call
      // arguments can span lines as long as the string itself is closed)
      if (inStr) {
        errors.push({
          line: i + 1,
          column: trimmed.lastIndexOf('"') + 1,
          message: 'unterminated string literal',
          severity: 'error',
        });
      }
    }

    // ── Check for semicolons ──────────────────────────────────────────
    if (trimmed.endsWith(';') && !trimmed.startsWith('for') && !trimmed.startsWith('//')) {
      errors.push({
        line: i + 1, column: trimmed.length,
        message: "unnecessary semicolon (Go doesn't use semicolons at end of statements)",
        severity: 'warning',
      });
    }

    // ── Check for var + := conflict ───────────────────────────────────
    if (/var\s+\w+\s*:=/.test(trimmed)) {
      errors.push({
        line: i + 1, column: trimmed.indexOf(':=') + 1,
        message: "cannot use ':=' with 'var' keyword (use either 'var x = value' or 'x := value')",
        severity: 'error',
      });
    }
  }
  return errors;
}

function checkImports(code: string): GoError[] {
  const errors: GoError[] = [];
  const lines = code.split('\n');
  const clean = stripComments(code);

  // ── Gather declared imports ──────────────────────────────────────────
  const declaredPackages: { name: string; alias: string; line: number }[] = [];

  // Multi-import block:  import ( "fmt" ; alias "path/pkg" )
  const importBlock = code.match(/import\s*\(([\s\S]*?)\)/);
  if (importBlock) {
    const blockLines = importBlock[1].split('\n');
    for (const bl of blockLines) {
      const pm = bl.match(/(?:(\w+)\s+)?"([^"]+)"/);
      if (pm) {
        const alias = pm[1] || pm[2].split('/').pop()!;
        const pkg = pm[2];
        const lineNum = lines.findIndex(l => l.includes(`"${pkg}"`)) + 1;
        declaredPackages.push({ name: pkg, alias, line: lineNum });
      }
    }
  }

  // Single-line imports:  import "fmt"  or  import alias "pkg"
  const singleRe = /^import\s+(?:(\w+)\s+)?"([^"]+)"/gm;
  let sm: RegExpExecArray | null;
  while ((sm = singleRe.exec(code)) !== null) {
    const alias = sm[1] || sm[2].split('/').pop()!;
    const pkg = sm[2];
    // Avoid duplicates from block parsing
    if (!declaredPackages.find(d => d.name === pkg)) {
      const lineNum = lines.findIndex(l => l.includes(`"${pkg}"`)) + 1;
      declaredPackages.push({ name: pkg, alias, line: lineNum });
    }
  }

  // ── Find used packages in code (outside imports) ────────────────────
  const usedAliases = new Set<string>();

  // Remove import declarations so we only scan actual code
  const codeBody = clean
    .replace(/import\s*\([\s\S]*?\)/g, '')
    .replace(/import\s+(?:\w+\s+)?"[^"]+"/g, '');

  // Collect locally declared variable / param / receiver names so we
  // don't confuse  myVar.Field  with a package reference.
  const localVars = new Set<string>();
  const declPatterns = [
    /(\w+)\s*:=/g,                                     // x := ...
    /var\s+(\w+)/g,                                    // var x ...
    /const\s+(\w+)/g,                                  // const x ...
    /func\s+\((\w+)\s+/g,                              // func (r Rect) — receiver
    /func\s+\w+\s*\(([^)]*)\)/g,                       // func foo(a int, b string)
    /for\s+(?:\w+\s*,\s*)?(\w+)\s*:=\s*range/g,        // for _, v := range
    /for\s+(\w+)\s*,/g,                                // for i, ...
    /for\s+(\w+)\s*:=/g,                               // for i := 0
  ];
  for (const pat of declPatterns) {
    let dm: RegExpExecArray | null;
    while ((dm = pat.exec(codeBody)) !== null) {
      const captured = dm[1];
      // For func params, split "a int, b string" into individual names
      if (captured.includes(',') || captured.includes(' ')) {
        const parts = captured.split(/[,]/).map(s => s.trim().split(/\s+/)[0]);
        for (const p of parts) { if (p && /^[a-zA-Z_]\w*$/.test(p)) localVars.add(p); }
      } else if (/^[a-zA-Z_]\w*$/.test(captured)) {
        localVars.add(captured);
      }
    }
  }
  // Also capture type names (type Foo struct) since Foo.Method is valid
  const typeRe = /type\s+(\w+)\s+/g;
  let tm: RegExpExecArray | null;
  while ((tm = typeRe.exec(codeBody)) !== null) {
    localVars.add(tm[1]);
  }

  // Match identifier.identifier — but NOT number.number (floats)
  const callRe = /\b([a-zA-Z_]\w*)\.(\w+)/g;
  let cm: RegExpExecArray | null;
  while ((cm = callRe.exec(codeBody)) !== null) {
    // Only treat it as a package reference if it's not a known local variable
    if (!localVars.has(cm[1])) {
      usedAliases.add(cm[1]);
    }
  }

  // ── Cross-reference ─────────────────────────────────────────────────
  const keywords = new Set(['main', 'func', 'var', 'const', 'type', 'if', 'else',
    'for', 'range', 'switch', 'case', 'default', 'return', 'break', 'continue',
    'go', 'defer', 'select', 'chan', 'map', 'struct', 'interface', 'package',
    'import', 'nil', 'true', 'false', 'iota', 'append', 'len', 'cap', 'make',
    'new', 'close', 'copy', 'delete', 'panic', 'recover', 'print', 'println']);

  for (const alias of usedAliases) {
    if (keywords.has(alias)) continue;
    if (!declaredPackages.find(d => d.alias === alias)) {
      const useLine = lines.findIndex(l => new RegExp(`\\b${alias}\\.\\w+`).test(l));
      if (useLine >= 0) {
        errors.push({
          line: useLine + 1, column: 1,
          message: `undefined: ${alias} (package "${alias}" is not imported)`,
          severity: 'error',
        });
      }
    }
  }

  for (const decl of declaredPackages) {
    if (decl.alias === '_') continue;
    if (!usedAliases.has(decl.alias)) {
      errors.push({
        line: decl.line, column: 1,
        message: `"${decl.name}" imported and not used`,
        severity: 'error',
      });
    }
  }

  return errors;
}

// ─── Output Simulation ─────────────────────────────────────────────────────

interface VarScope {
  [key: string]: { value: string; type: string };
}

/**
 * Extract the full argument string for a function call that may span
 * multiple lines.  Returns the text between the outer parentheses.
 */
function extractFullCall(lines: string[], startLine: number, startCol: number): { args: string; endLine: number } | null {
  let depth = 0;
  let result = '';
  let inStr = false;
  let inRaw = false;
  let inRune = false;
  let started = false;

  for (let li = startLine; li < lines.length; li++) {
    const line = lines[li];
    const begin = (li === startLine) ? startCol : 0;

    for (let ci = begin; ci < line.length; ci++) {
      const ch = line[ci];
      const nx = line[ci + 1] || '';

      if (inRaw) { result += ch; if (ch === '`') inRaw = false; continue; }
      if (inRune) {
        result += ch;
        if (ch === '\\') { result += nx; ci++; continue; }
        if (ch === "'") inRune = false;
        continue;
      }
      if (inStr) {
        result += ch;
        if (ch === '\\') { result += nx; ci++; continue; }
        if (ch === '"') inStr = false;
        continue;
      }

      if (ch === '/' && nx === '/') break; // line comment

      if (ch === '"')  { inStr = true; result += ch; continue; }
      if (ch === '`')  { inRaw = true; result += ch; continue; }
      if (ch === "'")  { inRune = true; result += ch; continue; }

      if (ch === '(') {
        depth++;
        if (!started) { started = true; continue; } // skip opening paren
        result += ch;
        continue;
      }
      if (ch === ')') {
        depth--;
        if (depth === 0) return { args: result, endLine: li };
        result += ch;
        continue;
      }

      if (started) result += ch;
    }
    if (started) result += ' '; // replace newline with space for continuations
  }
  return null;
}

function simulateOutput(code: string, userInputs?: string[]): string[] {
  const output: string[] = [];
  const vars: VarScope = {};
  const lines = code.split('\n');
  let inputIdx = 0;
  const getNextInput = (): string => {
    if (userInputs && inputIdx < userInputs.length) {
      return userInputs[inputIdx++];
    }
    return '';
  };

  // ── First pass: collect variable declarations ───────────────────────
  // Helper to parse a single declaration line (with or without "var"/"const" prefix)
  const parseDeclLine = (trimmed: string, insideBlock: 'var' | 'const' | null) => {
    if (trimmed.startsWith('//') || trimmed === '' || trimmed === '(' || trimmed === ')') return;

    // Remove leading "var" or "const" if present (standalone declarations)
    let line = trimmed;
    let declKind = insideBlock;
    if (line.startsWith('var '))   { line = line.slice(4).trim(); declKind = 'var'; }
    else if (line.startsWith('const ')) { line = line.slice(6).trim(); declKind = 'const'; }
    else if (!declKind) {
      // Not a declaration line — check for short declaration
      const shortDecl = trimmed.match(/^(\w+)\s*:=\s*(.+)$/);
      if (shortDecl) {
        const val = evaluateSimpleExpr(shortDecl[2].trim(), vars);
        vars[shortDecl[1]] = val;
      }
      return;
    }

    if (!declKind) return;

    // name type = expr
    const typedAssign = line.match(/^(\w+)\s+[\w*[\]]+\s*=\s*(.+)$/);
    if (typedAssign) {
      const val = evaluateSimpleExpr(typedAssign[2].trim(), vars);
      vars[typedAssign[1]] = val;
      return;
    }

    // name = expr  (type inferred or inside block)
    const inferredAssign = line.match(/^(\w+)\s*=\s*(.+)$/);
    if (inferredAssign) {
      const val = evaluateSimpleExpr(inferredAssign[2].trim(), vars);
      vars[inferredAssign[1]] = val;
      return;
    }

    // name type  (zero value, no assignment)
    if (declKind === 'var') {
      const zeroVal = line.match(/^(\w+)\s+(.+)$/);
      if (zeroVal) {
        const typeName = zeroVal[2].trim();
        if (/^(int\d*|uint\d*|float\d*|byte|rune|complex\d*|uintptr)$/.test(typeName)) {
          vars[zeroVal[1]] = { value: '0', type: typeName };
        } else if (typeName === 'string') {
          vars[zeroVal[1]] = { value: '', type: 'string' };
        } else if (typeName === 'bool') {
          vars[zeroVal[1]] = { value: 'false', type: 'bool' };
        }
        // For pointer/struct/interface types, leave as undefined
      }
    }
  };

  let insideVarBlock: 'var' | 'const' | null = null;

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//')) continue;

    // Detect start of var/const block
    if (trimmed === 'var (' || trimmed === 'var(') {
      insideVarBlock = 'var'; continue;
    }
    if (trimmed === 'const (' || trimmed === 'const(') {
      insideVarBlock = 'const'; continue;
    }
    if (insideVarBlock && trimmed === ')') {
      insideVarBlock = null; continue;
    }

    parseDeclLine(trimmed, insideVarBlock);
  }

  // ── Second pass: process print AND scan statements in order ──────────
  for (let li = 0; li < lines.length; li++) {
    const trimmed = lines[li].trim();
    if (trimmed.startsWith('//')) continue;

    // ── Handle fmt.Scan / fmt.Scanln ──────────────────────────────────
    const scanMatch = trimmed.match(/fmt\.(Scan|Scanln)\s*\(\s*&(\w+)/);
    if (scanMatch) {
      const inputVal = getNextInput();
      const varName = scanMatch[2];
      // Try to infer type from input
      if (/^-?\d+$/.test(inputVal)) {
        vars[varName] = { value: inputVal, type: 'int' };
      } else if (/^-?\d+\.\d+$/.test(inputVal)) {
        vars[varName] = { value: inputVal, type: 'float64' };
      } else {
        vars[varName] = { value: inputVal, type: 'string' };
      }
      continue;
    }

    // ── Handle fmt.Scanf ──────────────────────────────────────────────
    const scanfMatch = trimmed.match(/fmt\.Scanf\s*\(\s*"([^"]*)"(.*)\)/);
    if (scanfMatch) {
      const varNames = [...scanfMatch[2].matchAll(/&(\w+)/g)].map(m => m[1]);
      for (const vn of varNames) {
        const inputVal = getNextInput();
        if (/^-?\d+$/.test(inputVal)) {
          vars[vn] = { value: inputVal, type: 'int' };
        } else if (/^-?\d+\.\d+$/.test(inputVal)) {
          vars[vn] = { value: inputVal, type: 'float64' };
        } else {
          vars[vn] = { value: inputVal, type: 'string' };
        }
      }
      continue;
    }

    // ── Handle bufio scanner .Text() result ───────────────────────────
    const textMatch = trimmed.match(/(\w+)\s*(?::=|=)\s*\w+\.Text\s*\(\s*\)/);
    if (textMatch) {
      vars[textMatch[1]] = { value: getNextInput(), type: 'string' };
      continue;
    }

    // ── Handle bufio reader .ReadString result ────────────────────────
    const readStrMatch = trimmed.match(/(\w+)(?:\s*,\s*\w+)?\s*(?::=|=)\s*\w+\.ReadString\s*\(/);
    if (readStrMatch) {
      vars[readStrMatch[1]] = { value: getNextInput(), type: 'string' };
      continue;
    }

    // ── Handle fmt.Print / fmt.Println / fmt.Printf ───────────────────
    const printCall = trimmed.match(/fmt\.(Println|Printf|Print)\s*\(/);
    if (!printCall) continue;

    const funcName = printCall[1];
    const extracted = extractFullCall(lines, li, lines[li].indexOf('(', lines[li].indexOf(`fmt.${funcName}`)));
    if (!extracted) continue;

    const { args: argsStr } = extracted;

    switch (funcName) {
      case 'Println': {
        if (argsStr.trim() === '') {
          output.push('');
        } else {
          const args = parseArgList(argsStr, vars);
          output.push(args.join(' '));
        }
        break;
      }
      case 'Print': {
        const args = parseArgList(argsStr, vars);
        output.push(args.join(' '));
        break;
      }
      case 'Printf': {
        const result = handlePrintf(argsStr, vars);
        output.push(result);
        break;
      }
    }
  }

  return output;
}

function evaluateSimpleExpr(expr: string, vars: VarScope): { value: string; type: string } {
  const trimmed = expr.replace(/,\s*$/, '').trim();

  // String literal
  if (trimmed.startsWith('"') && trimmed.endsWith('"')) {
    return { value: trimmed.slice(1, -1).replace(/\\n/g, '\n').replace(/\\t/g, '\t'), type: 'string' };
  }
  // Raw string
  if (trimmed.startsWith('`') && trimmed.endsWith('`')) {
    return { value: trimmed.slice(1, -1), type: 'string' };
  }
  // Boolean
  if (trimmed === 'true' || trimmed === 'false') {
    return { value: trimmed, type: 'bool' };
  }
  // Rune / character literal
  if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
    const inner = trimmed.slice(1, -1);
    // Store the numeric code point so %c can render it
    if (inner.length === 1) {
      return { value: String(inner.charCodeAt(0)), type: 'rune' };
    }
    // Escape sequences like '\n'
    const escMap: Record<string, number> = { '\\n': 10, '\\t': 9, '\\r': 13, '\\\\': 92, "\\'": 39 };
    if (escMap[inner] !== undefined) {
      return { value: String(escMap[inner]), type: 'rune' };
    }
    return { value: inner, type: 'rune' };
  }
  // Float
  if (/^-?\d+\.\d+$/.test(trimmed)) {
    return { value: trimmed, type: 'float64' };
  }
  // Int
  if (/^-?\d+$/.test(trimmed)) {
    return { value: trimmed, type: 'int' };
  }
  // nil
  if (trimmed === 'nil') {
    return { value: '<nil>', type: 'nil' };
  }
  // Variable reference
  if (vars[trimmed]) {
    return { ...vars[trimmed] };
  }

  // Simple binary expressions: a OP b
  const binOps: [RegExp, (a: number, b: number) => number][] = [
    [/^(.+?)\s*\+\s*(.+)$/, (a, b) => a + b],
    [/^(.+?)\s*-\s*(.+)$/, (a, b) => a - b],
    [/^(.+?)\s*\*\s*(.+)$/, (a, b) => a * b],
    [/^(.+?)\s*\/\s*(.+)$/, (a, b) => b !== 0 ? a / b : 0],
    [/^(.+?)\s*%\s*(.+)$/, (a, b) => a % b],
  ];
  for (const [re, op] of binOps) {
    const match = trimmed.match(re);
    if (match) {
      const aVal = evaluateSimpleExpr(match[1].trim(), vars);
      const bVal = evaluateSimpleExpr(match[2].trim(), vars);
      const numA = Number(aVal.value);
      const numB = Number(bVal.value);
      if (!isNaN(numA) && !isNaN(numB)) {
        const result = op(numA, numB);
        const isFloat = aVal.type.startsWith('float') || bVal.type.startsWith('float') || !Number.isInteger(result);
        return { value: String(result), type: isFloat ? 'float64' : 'int' };
      }
      // String concatenation
      if (aVal.type === 'string' && bVal.type === 'string' && re === binOps[0][0]) {
        return { value: aVal.value + bVal.value, type: 'string' };
      }
    }
  }

  // Function calls we can resolve (e.g. len, cap — just return placeholder)
  if (/^len\s*\(/.test(trimmed)) return { value: '0', type: 'int' };
  if (/^cap\s*\(/.test(trimmed)) return { value: '0', type: 'int' };

  return { value: trimmed, type: 'unknown' };
}

function parseArgList(argsStr: string, vars: VarScope): string[] {
  const args: string[] = [];
  let current = '';
  let depth = 0;
  let inStr = false;
  let inRaw = false;
  let inRune = false;

  for (let i = 0; i < argsStr.length; i++) {
    const ch = argsStr[i];
    const nx = argsStr[i + 1] || '';

    if (inRaw) {
      current += ch;
      if (ch === '`') inRaw = false;
      continue;
    }
    if (inRune) {
      current += ch;
      if (ch === '\\') { current += nx; i++; continue; }
      if (ch === "'") inRune = false;
      continue;
    }
    if (inStr) {
      current += ch;
      if (ch === '\\') { current += nx; i++; continue; }
      if (ch === '"') inStr = false;
      continue;
    }

    if (ch === '"')  { inStr = true;  current += ch; continue; }
    if (ch === '`')  { inRaw = true;  current += ch; continue; }
    if (ch === "'")  { inRune = true; current += ch; continue; }
    if (ch === '(')  { depth++; current += ch; continue; }
    if (ch === ')')  { depth--; current += ch; continue; }

    if (ch === ',' && depth === 0) {
      args.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  if (current.trim()) args.push(current.trim());

  return args.map(arg => evaluateSimpleExpr(arg, vars).value);
}

function handlePrintf(argsStr: string, vars: VarScope): string {
  const rawArgs = parseArgList(argsStr, vars);
  if (rawArgs.length === 0) return '';

  let format = rawArgs[0];
  // Process escape sequences
  format = format.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\\\/g, '\\');

  const values = rawArgs.slice(1);
  let argIdx = 0;

  const result = format.replace(/%([#+\-0 ]*\d*\.?\d*[sdftvcxXqpboOeEgGUT%])/g, (_match, spec: string) => {
    const verb = spec[spec.length - 1];
    if (verb === '%') return '%';
    if (argIdx >= values.length) return `%!${verb}(MISSING)`;

    const val = values[argIdx++];

    switch (verb) {
      case 's': return val;
      case 'd': return String(parseInt(val) || 0);
      case 'f': {
        const precMatch = spec.match(/\.(\d+)/);
        const prec = precMatch ? parseInt(precMatch[1]) : 6;
        return (parseFloat(val) || 0).toFixed(prec);
      }
      case 't': return val === 'true' ? 'true' : 'false';
      case 'v': return val;
      case 'c': {
        const code = parseInt(val);
        return !isNaN(code) ? String.fromCharCode(code) : val;
      }
      case 'x': case 'X': return (parseInt(val) || 0).toString(16);
      case 'o': case 'O': return (parseInt(val) || 0).toString(8);
      case 'b': return (parseInt(val) || 0).toString(2);
      case 'q': return `"${val}"`;
      case 'p': return '0x' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
      case 'e': case 'E': return (parseFloat(val) || 0).toExponential();
      case 'g': case 'G': return String(parseFloat(val) || 0);
      case 'T': return typeof val === 'string' ? 'string' : 'int';
      case 'U': return 'U+' + (parseInt(val) || 0).toString(16).toUpperCase().padStart(4, '0');
      default: return val;
    }
  });

  return result;
}

// ─── Input Detection ───────────────────────────────────────────────────────

/** Detect fmt.Scan/Scanln/Scanf and bufio.Scanner calls and return prompt labels */
export function detectInputCalls(code: string): { needsInput: boolean; prompts: string[] } {
  const prompts: string[] = [];
  const lines = code.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (trimmed.startsWith('//')) continue;

    // fmt.Scan(&var)
    const scanMatch = trimmed.match(/fmt\.Scan\s*\(\s*&(\w+)/);
    if (scanMatch) {
      // Look at the previous print line for a prompt label
      const prompt = findPrecedingPrompt(lines, i) || scanMatch[1];
      prompts.push(prompt);
      continue;
    }

    // fmt.Scanln(&var)
    const scanlnMatch = trimmed.match(/fmt\.Scanln\s*\(\s*&(\w+)/);
    if (scanlnMatch) {
      const prompt = findPrecedingPrompt(lines, i) || scanlnMatch[1];
      prompts.push(prompt);
      continue;
    }

    // fmt.Scanf("format", &var1, &var2...)
    const scanfMatch = trimmed.match(/fmt\.Scanf\s*\(\s*"([^"]*)"(.*)\)/);
    if (scanfMatch) {
      const formatStr = scanfMatch[1];
      const argsPart = scanfMatch[2];
      const varNames = [...argsPart.matchAll(/&(\w+)/g)].map(m => m[1]);
      // Count format verbs
      const verbs = formatStr.match(/%\w/g) || [];
      const count = Math.max(verbs.length, varNames.length, 1);
      for (let v = 0; v < count; v++) {
        const prompt = findPrecedingPrompt(lines, i) || varNames[v] || `input${v + 1}`;
        if (v === 0) prompts.push(prompt);
        else prompts.push(varNames[v] || `input${v + 1}`);
      }
      continue;
    }

    // bufio.NewScanner / scanner.Scan / reader.ReadString
    if (/bufio\.NewScanner|\.Scan\s*\(\s*\)|reader\.ReadString|bufio\.NewReader/.test(trimmed)) {
      // Find the variable name being assigned the scanner result
      const scanTextMatch = trimmed.match(/(\w+)\s*(?::=|=)\s*.*\.Text\s*\(\s*\)/);
      if (scanTextMatch) {
        const prompt = findPrecedingPrompt(lines, i) || scanTextMatch[1];
        prompts.push(prompt);
        continue;
      }
      // Check surrounding lines for .Text() calls
      for (let j = i; j < Math.min(i + 5, lines.length); j++) {
        const t = lines[j].trim();
        const textMatch = t.match(/(\w+)\s*(?::=|=)\s*\w+\.Text\s*\(\s*\)/);
        if (textMatch) {
          const prompt = findPrecedingPrompt(lines, j) || textMatch[1];
          prompts.push(prompt);
          break;
        }
      }
      if (prompts.length === 0 && /bufio\.NewScanner|bufio\.NewReader/.test(trimmed)) {
        prompts.push(findPrecedingPrompt(lines, i) || 'input');
      }
    }
  }

  return { needsInput: prompts.length > 0, prompts };
}

/** Look backward from line index to find a fmt.Print/Println that serves as the prompt text */
function findPrecedingPrompt(lines: string[], fromIndex: number): string {
  for (let j = fromIndex - 1; j >= Math.max(0, fromIndex - 3); j--) {
    const prev = lines[j].trim();
    // fmt.Print("Enter your name: ")
    const printPrompt = prev.match(/fmt\.(?:Print|Printf|Println)\s*\(\s*"([^"]+)"/);
    if (printPrompt) {
      let label = printPrompt[1]
        .replace(/\\n/g, '')
        .replace(/:?\s*$/, '')
        .replace(/%\w/g, '')
        .trim();
      if (label.length > 0 && label.length < 60) return label;
    }
  }
  return '';
}

// ─── Main Entry Point ──────────────────────────────────────────────────────

export function runGoCode(code: string, userInputs?: string[]): RunResult {
  const allErrors: GoError[] = [];

  allErrors.push(...checkPackageDeclaration(code));
  allErrors.push(...checkBraces(code));
  allErrors.push(...checkFuncDeclarationBraces(code));
  allErrors.push(...checkCommonMistakes(code));
  allErrors.push(...checkImports(code));
  allErrors.push(...checkMainFunction(code));

  // De-duplicate errors (same line + same message)
  const seen = new Set<string>();
  const unique = allErrors.filter(e => {
    const key = `${e.line}:${e.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const errors = unique.filter(e => e.severity === 'error');
  const warnings = unique.filter(e => e.severity === 'warning');

  // Detect input needs
  const { needsInput, prompts } = detectInputCalls(code);

  if (errors.length > 0) {
    errors.sort((a, b) => a.line - b.line || a.column - b.column);
    const errorLines = errors.map(e => `./main.go:${e.line}:${e.column}: ${e.message}`);
    let output = `# command-line-arguments\n${errorLines.join('\n')}`;
    if (warnings.length > 0) {
      output += '\n' + warnings.map(w => `./main.go:${w.line}:${w.column}: warning: ${w.message}`).join('\n');
    }
    return { success: false, output, errors: unique, needsInput: false, inputPrompts: [] };
  }

  // Simulate output with user inputs
  const outputLines = simulateOutput(code, userInputs);

  let output: string;
  if (outputLines.length > 0) {
    output = outputLines.join('\n');
  } else {
    output = '// Program executed successfully (no output)';
  }

  if (warnings.length > 0) {
    output += '\n\n' + warnings.map(w => `⚠ line ${w.line}: ${w.message}`).join('\n');
  }

  return { success: true, output, errors: warnings, needsInput, inputPrompts: prompts };
}
