import { AppProvider, useApp } from './store/AppContext';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import LessonsDashboard from './pages/LessonsDashboard';
import LessonPage from './pages/LessonPage';
import PracticePage from './pages/PracticePage';
import ProjectsPage from './pages/ProjectsPage';
import AuthPage from './pages/AuthPage';

function AppContent() {
  const { page } = useApp();

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <HomePage />;
      case 'lessons':
        return <LessonsDashboard />;
      case 'lesson':
        return <LessonPage />;
      case 'practice':
        return <PracticePage />;
      case 'projects':
        return <ProjectsPage />;
      case 'auth':
        return <AuthPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--bg-primary)' }}>
      <Navbar />
      <main>{renderPage()}</main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
